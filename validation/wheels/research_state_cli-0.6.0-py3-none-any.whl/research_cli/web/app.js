/* Agent-operated research observatory. No human action handlers. */
const $ = (id) => document.getElementById(id);
const PAGE = 20;
const state = {token: null, tools: [], workspace: '', scene: 'overview', selected: '',
  snapshot: null, record: null, summary: null, goal: null, limit: PAGE, offset: 0,
  memory: null, memoryArgs: {query: '', outcome: null, verification: null, limit: PAGE, offset: 0},
  evidence: null, calls: [], pending: 0, serial: 0, latest: 0, refreshing: null,
  connected: false, explanation: '', fingerprints: new Map(), booted: false, refreshScope: '', summarySignature: ''};
const labels = {registered: '조건 고정', running: '실행 중', succeeded: '실행 성공', failed: '실패',
  unknown: '실행 미확정', pending: '대기', passed: '검증 통과', adopted: '채택', rejected: '기각',
  inconclusive: '미결', valid: '해시 일치', tampered: '변조 감지', missing: '파일 누락',
  no_file: '파일 없는 주장', measured: '측정값', literature: '문헌 주장', inference: '추론',
  proposal: '미실행 제안', success: '성공', failure: '실패', recorded: '목표 기록', proposed: '가설 제안',
  verified_claim: '검증 확인', unverified: '미검증'};
const stages = ['목표', '가설', '사전등록', '실행', '검증', '결정'];
const scenes = {overview: ['연구 관측실', '실제 연구의 관계와 증거를 에이전트가 펼칩니다.'],
  memory: ['연구 기억', '에이전트가 검색한 기록과 주장의 검증 여부를 함께 봅니다.'],
  evidence: ['원본 증거', '에이전트가 선택한 보존 파일을 해시와 함께 읽습니다.'],
  activity: ['연구 타임라인', '저장된 연구 사건과 이 페이지의 도구 호출을 구분합니다.']};
const eventNames = {'goal.create': '목표 기록', 'hypothesis.create': '가설 기록',
  'validator.register': '검증기 고정', 'registration.create': '사전등록', 'run.claim': '실행 요청 확보',
  'run.complete': '실행 증거 수집', 'run.unknown': '실행 여부 미확정',
  'verification.complete': '독립 검증', 'decision.create': '결정 기록', 'evidence.add': '증거 연결'};

/** Presentation tools live in the browser document, never in state dispatch. */
export const presentationTools = [{name: 'research_view',
  description: 'Control the spectator display without human clicks or research mutations. Show a workspace, selected experiment, paginated overview, memory search, or activity. A person asks the external agent what to see; the agent calls this tool. explanation is an agent statement, not verified evidence.',
  inputSchema: {type: 'object', additionalProperties: false, properties: {
    workspace: {type: 'string', description: 'Relative workspace; defaults to the current display or default.'},
    scene: {type: 'string', enum: ['overview', 'memory', 'activity'], default: 'overview'},
    registration: {type: 'string', description: 'Optional experiment to focus, including an off-page record.'},
    query: {type: 'string', default: ''},
    outcome: {type: ['string', 'null'], enum: [null, 'success', 'failure', 'inconclusive']},
    verification: {type: ['string', 'null'], enum: [null, 'pending', 'passed', 'failed', 'inconclusive']},
    limit: {type: 'integer', minimum: 1, maximum: 100, default: PAGE},
    offset: {type: 'integer', minimum: 0, default: 0},
    explanation: {type: 'string', maxLength: 2000, description: 'External-agent explanation, explicitly unverified.'}}},
  annotations: {readOnlyHint: true}},
  {name: 'research_inspect_evidence',
    description: 'Open preserved evidence in the spectator scene without a human click. Obtain evidence IDs with research_show first. Checks the linked file hash through the existing evidence API. Does not execute, verify, adopt, or change research state. Return to another scene with research_view.',
    inputSchema: {type: 'object', additionalProperties: false, required: ['registration', 'evidence'], properties: {
      workspace: {type: 'string'}, registration: {type: 'string'}, evidence: {type: 'string'},
      explanation: {type: 'string', maxLength: 2000}}}, annotations: {readOnlyHint: true}}];

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined && text !== null) node.textContent = String(text);
  return node;
}
function svg(tag, attrs = {}, text) {
  const node = document.createElementNS('http://www.w3.org/2000/svg', tag);
  for (const [key, value] of Object.entries(attrs)) node.setAttribute(key, String(value));
  if (text !== undefined) node.textContent = text;
  return node;
}
function json(value) { return JSON.stringify(value, null, 2); }
function finiteJson(value) { return JSON.stringify(value, (_key, item) => {
  if (typeof item === 'number' && !Number.isFinite(item)) throw new Error('Input must be finite JSON.'); return item;
}); }
function tone(value) {
  if (['succeeded', 'passed', 'adopted', 'valid', 'success', 'verified_claim'].includes(value)) return 'good';
  if (['running', 'unknown', 'inconclusive', 'unverified'].includes(value)) return 'warn';
  if (['failed', 'rejected', 'tampered', 'missing', 'failure'].includes(value)) return 'bad'; return 'quiet';
}
function badge(value, prefix = '') { return el('span', `state-badge ${tone(value)}`, prefix + (labels[value] || value || '—')); }
function chips(row) { return [badge(row.execution || 'registered', '실행 · '), badge(row.verification || 'pending', '검증 · '), badge(row.decision || 'pending', '결정 · ')]; }
function time(value) {
  if (!value) return '—'; const date = new Date(typeof value === 'number' ? value * 1000 : value);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat('ko-KR', {timeZone: 'Asia/Seoul', hour: '2-digit', minute: '2-digit', second: '2-digit'}).format(date);
}
function qs(value) { return new URLSearchParams(Object.entries(value).filter(([, item]) => item !== undefined && item !== null)).toString(); }
function status() { return state.snapshot?.status || {goals: [], hypotheses: [], registrations: [], revision: null, total: 0}; }
function envelopeError(code, message, details = {}) { return {ok: false, error: {code, message, details}}; }
function errorText(result) { return `${result.error?.code || 'ERROR'} · ${result.error?.message || '조회할 수 없습니다.'}`; }
function notify(text = '') { $('notice').textContent = text; $('notice').hidden = !text; }
function animate(node, keyframes = [{opacity: 0, transform: 'translateY(12px)'}, {opacity: 1, transform: 'translateY(0)'}]) {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches || typeof node.animate !== 'function') return;
  for (const current of node.getAnimations()) current.cancel();
  node.animate(keyframes, {duration: 440, easing: 'cubic-bezier(.2,.8,.2,1)'});
}
function replaceChanged(node, fingerprint, children) {
  if (state.fingerprints.get(node.id) === fingerprint) return;
  state.fingerprints.set(node.id, fingerprint); node.replaceChildren(...children); animate(node);
}
function connection(online) {
  state.connected = online;
  $('connection-status').textContent = online ? 'LOCAL STATE · 연결' : 'LOCAL STATE · 재연결 대기';
  $('connection-status').dataset.state = online ? 'connected' : 'disconnected';
}
async function request(path, options = {}) {
  try {
    const response = await fetch(path, {cache: 'no-store', credentials: 'same-origin', ...options}); const result = await response.json();
    if (!result || typeof result.ok !== 'boolean') throw new Error('Invalid response envelope.'); connection(true); return result;
  } catch (error) { connection(false); state.token = null; return envelopeError('CONNECTION_ERROR', error.message || 'Local server unavailable.'); }
}
async function ensureSession() {
  const response = await request('/api/bootstrap');
  if (response.ok) { state.token = response.data.session_token; $('app-version').textContent = response.data.version; } return response;
}
async function core(name, args) { return request('/api/call', {method: 'POST', headers: {'Content-Type': 'application/json', 'X-Research-Session': state.token}, body: finiteJson({tool: name, arguments: args})}); }
function relativeWorkspace(value) { return typeof value === 'string' && value.length > 0 && !/^[\\/]|^[A-Za-z]:/.test(value) && !value.split(/[\\/]/).some((part) => part === '..'); }
function workspace(name) {
  if (name === state.workspace) return;
  state.workspace = name; state.selected = ''; state.snapshot = null; state.record = null; state.summary = null;
  state.goal = null; state.evidence = null; state.memory = null; state.offset = 0; state.summarySignature = ''; state.fingerprints.clear();
  $('workspace-name').textContent = name || '에이전트 연결 대기';
  try { localStorage.setItem('research-state-workspace', name); } catch (_) { /* Reading never requires browser storage. */ }
}
function setScene(scene) {
  const changed = state.scene !== scene; state.scene = scene; document.body.dataset.scene = scene;
  for (const item of ['memory', 'evidence', 'activity']) $(`${item}-panel`).hidden = scene !== item;
  $('scene-title').textContent = scenes[scene][0];
  $('scene-caption').textContent = state.explanation ? `에이전트 설명 · ${state.explanation} (검증된 증거와 별개)` : scenes[scene][1];
  if (changed) animate($(scene === 'overview' ? 'graph-host' : `${scene}-panel`));
}
export function getViewState() { return {workspace: state.workspace, scene: state.scene, selectedRegistration: state.selected,
  revision: status().revision, limit: state.limit, offset: state.offset, pendingCalls: state.pending,
  connected: state.connected, humanControls: false, memory: {...state.memoryArgs}, evidence: state.evidence?.evidence?.id || null}; }
function metric(id, value) {
  const node = $(id), text = String(value ?? 0);
  if (node.textContent !== text) { node.textContent = text; animate(node, [{opacity: .3, transform: 'translateY(8px)'}, {opacity: 1, transform: 'translateY(0)'}]); }
}
function stageStates() {
  const record = state.record, selected = Boolean(record), s = status();
  return [selected || s.goal_total ? 'recorded' : 'pending', selected || s.hypothesis_total ? 'proposed' : 'pending',
    selected ? 'registered' : 'pending', record?.run?.state || 'pending', record?.verification?.state || 'pending', record?.decision?.state || 'pending'];
}
function drawGraph() {
  const values = stageStates(), record = state.record;
  const compact = matchMedia('(max-width: 620px)').matches;
  const fingerprint = json({compact, values, selected: state.selected, evidence: record?.evidence?.map((item) => [item.id, item.integrity]), goals: status().goal_total, hypotheses: status().hypothesis_total});
  $('graph-context').textContent = state.selected ? `FOCUS ${state.selected.slice(-8)} · REV ${status().revision ?? '—'}` : '에이전트가 실험을 선택하면 관계가 연결됩니다';
  if (state.fingerprints.get('graph-host') === fingerprint) return;
  const drawing = svg('svg', {viewBox: compact ? '0 0 460 690' : '0 0 900 510', role: 'img', 'aria-labelledby': 'graph-access-title graph-access-description'});
  drawing.append(svg('title', {id: 'graph-access-title'}, '실제 연구 상태 관계 그래프'), svg('desc', {id: 'graph-access-description'}, stages.map((stage, i) => `${stage}: ${labels[values[i]] || values[i]}`).join(', ')));
  const defs = svg('defs'), gradient = svg('linearGradient', {id: 'edge-gradient', x1: '0%', x2: '100%'});
  gradient.append(svg('stop', {offset: '0%', 'stop-color': '#244e62'}), svg('stop', {offset: '100%', 'stop-color': '#62e6c3'})); defs.append(gradient); drawing.append(defs);
  const paths = compact ? ['M164 130 L291 130', 'M345 184 L345 276', 'M291 330 L164 330', 'M110 384 L110 476', 'M164 530 L291 530']
    : ['M152 240 L212 240', 'M320 240 L380 240', 'M488 240 C538 240 528 148 556 148', 'M664 148 C721 148 721 340 664 340', 'M664 340 C734 340 734 240 740 240'];
  paths.forEach((path, i) => drawing.append(svg('path', {d: path, class: `graph-edge ${values[i + 1] !== 'pending' ? 'observed' : ''}`, fill: 'none', 'data-edge': i})));
  const points = compact ? [[110, 130], [345, 130], [345, 330], [110, 330], [110, 530], [345, 530]]
    : [[98, 240], [266, 240], [434, 240], [610, 148], [610, 340], [794, 240]];
  points.forEach(([x, y], i) => {
    const group = svg('g', {class: 'graph-node', 'data-stage': i, 'data-state': values[i], transform: `translate(${x} ${y})`});
    group.append(svg('circle', {r: 61, class: 'node-halo'}), svg('circle', {r: 48, class: 'node-orbit'}), svg('rect', {x: -42, y: -42, width: 84, height: 84, rx: 24, class: 'node-core'}),
      svg('text', {class: 'graph-node-symbol', 'text-anchor': 'middle', y: 8}, String(i + 1).padStart(2, '0')), svg('text', {class: 'graph-node-label', 'text-anchor': 'middle', y: 76}, stages[i]),
      svg('text', {class: 'graph-node-caption', 'text-anchor': 'middle', y: 98}, i < 2 ? (record ? '등록에 연결됨' : `${i === 0 ? status().goal_total || 0 : status().hypothesis_total || 0}개 기록`) : labels[values[i]] || values[i])); drawing.append(group);
  });
  const proof = record?.evidence || [], valid = proof.filter((item) => item.integrity === 'valid').length;
  drawing.append(svg('text', {x: compact ? 24 : 40, y: 42, class: 'graph-kicker'}, compact ? 'STATE → EVIDENCE → DECISION' : 'GOAL → HYPOTHESIS → REGISTER → RUN → VERIFY → DECIDE'),
    svg('text', {x: compact ? 24 : 40, y: compact ? 650 : 464, class: 'graph-proof'}, record ? `보존 증거 ${proof.length}개 · 해시 일치 ${valid}개` : '실험을 고르는 주체는 외부 에이전트입니다.'),
    svg('text', {x: compact ? 24 : 40, y: compact ? 675 : 487, class: 'graph-note'}, compact ? '실행 · 검증 · 결정은 별개의 상태입니다.' : '실행 성공 · 검증 통과 · 가설 채택은 각각 다른 상태입니다.'));
  replaceChanged($('graph-host'), fingerprint, [drawing]); pulseGraph();
}
function pulseGraph() {
  const call = state.calls.find((item) => !item.result), tool = call?.tool || '';
  const map = {research_goal: 0, research_hypothesis: 1, research_register: 2, research_run: 3, research_recover: 3, research_verify: 4, research_decide: 5};
  document.querySelectorAll('.graph-node').forEach((node) => node.classList.toggle('agent-focus', Number(node.dataset.stage) === map[tool]));
  document.querySelectorAll('.graph-edge').forEach((node) => node.classList.toggle('agent-flow', Boolean(call)));
}
function grid(entries) {
  const node = el('dl', 'data-grid'); entries.forEach(([key, value]) => { const item = el('div'); item.append(el('dt', '', key), el('dd', '', value ?? 'unknown')); node.append(item); }); return node;
}
function section(label, content) {
  const node = el('section', 'focus-section'); node.append(el('h3', 'focus-label', label));
  node.append(...(Array.isArray(content) ? content : [typeof content === 'string' ? el('p', 'focus-value', content) : content])); return node;
}
function resourceEntries(resources = {}) { return Object.entries(resources).map(([key, value]) => [key, value && typeof value === 'object' ? (value.status === 'unknown' ? 'unknown · 확인 불가' : value.value ?? json(value)) : value]); }
function metricChart(record) {
  const entries = Object.entries(record.verification?.metrics || {}), criteria = record.registration.spec.criteria || [], fragment = el('div', 'metric-chart');
  if (!entries.length) return el('p', 'quiet', '독립 검증 수치가 아직 없습니다.');
  entries.slice(0, 10).forEach(([name, value]) => {
    const criterion = criteria.find((item) => item.metric === name), row = el('div', 'chart-row'); row.append(el('span', 'chart-label', name), el('strong', 'chart-value', value));
    if (typeof value === 'number' && Number.isFinite(value) && criterion && typeof criterion.threshold === 'number' && criterion.threshold >= 0 && value >= 0) {
      const max = Math.max(value, criterion.threshold, 1), chart = svg('svg', {viewBox: '0 0 250 24', role: 'img', 'aria-label': `${name}: ${value}, 등록 기준 ${criterion.op} ${criterion.threshold}`});
      chart.append(svg('rect', {x: 0, y: 8, width: 250, height: 8, rx: 4, class: 'metric-track'}), svg('rect', {x: 0, y: 8, width: 250 * value / max, height: 8, rx: 4, class: 'metric-fill'}), svg('line', {x1: 250 * criterion.threshold / max, x2: 250 * criterion.threshold / max, y1: 1, y2: 23, class: 'metric-threshold'}));
      row.append(chart, el('small', 'quiet', `고정 기준 ${criterion.op} ${criterion.threshold} · 눈금 0–${max}`));
    } else row.append(el('small', 'quiet', criterion ? `고정 기준 ${criterion.op} ${criterion.threshold}` : '지표의 수치 · 비교 기준 없음')); fragment.append(row);
  });
  if (entries.length > 10) fragment.append(el('small', 'quiet', `첫 10/${entries.length}개 지표 · 전체 JSON은 research_show로 조회`)); return fragment;
}
function drawFocus() {
  const record = state.record, node = $('focus-panel');
  if (!record) {
    const children = [el('span', 'eyebrow', 'AGENT FOCUS'), el('h2', '', '에이전트의 시선을 기다립니다'), el('p', 'quiet', '보고 싶은 데이터와 진척도를 외부 에이전트에게 요청하세요. 화면의 선택·검색·전환은 에이전트가 수행합니다.')];
    const goals = status().goals || [], hypotheses = status().hypotheses || [];
    if (goals.length) children.push(section('현재 페이지의 연구 목표', goals.map((item) => el('p', '', item.title))));
    if (hypotheses.length) children.push(section('현재 페이지의 가설', hypotheses.map((item) => el('p', '', item.statement))));
    replaceChanged(node, json({goals, hypotheses, workspace: state.workspace}), children); return;
  }
  const spec = record.registration.spec, proof = record.evidence || [], invalid = proof.filter((item) => ['tampered', 'missing'].includes(item.integrity));
  const badges = el('div', 'state-line'); badges.append(...chips({execution: record.run?.state || 'registered', verification: record.verification?.state || 'pending', decision: record.decision?.state || 'pending'}));
  const children = [el('span', 'eyebrow', 'AGENT FOCUS'), el('h2', '', spec.change), el('p', 'mono quiet', record.registration.id), badges];
  if (invalid.length) children.push(el('p', 'integrity-warning', `현재 증거 ${invalid.length}개의 변조·누락 감지. 과거 검증 통과와 현재 무결성을 구분하세요.`));
  children.push(section('연구 목표', state.goal?.title || record.registration.goal_id), section('연결된 가설', record.hypothesis.statement), section('독립 검증 수치', metricChart(record)),
    section('고정 기준', el('pre', 'criteria-json', json({comparison: spec.comparison, data_split: spec.data_split, seed: spec.seed, metrics: spec.metrics, criteria: spec.criteria}))),
    section('현재 허용된 작업', el('p', 'mono', state.summary?.allowed_actions?.join(' · ') || '현재 페이지 상태에서 확인 필요')),
    section('부족한 증거', state.summary?.missing_evidence?.length ? state.summary.missing_evidence.join(' · ') : state.summary ? '현재 상태에서 추가로 요구되는 증거 없음' : '해당 등록의 상태 조회 필요'),
    section('자원 기록', grid(resourceEntries(record.run?.resources || {external_model_usage: 'unknown', external_tokens: 'unknown'}))),
    section('원본 증거 연결', proof.slice(0, 10).map((item) => { const entry = el('div', 'evidence-summary'); entry.append(el('strong', '', item.name || labels[item.kind]), badge(item.integrity), el('small', '', `${labels[item.kind]} · ${item.verified ? '검증과 연결됨' : '주장 검증과 별개'}`), el('small', 'mono', item.id), el('small', 'mono hash', item.sha256 || '원본 파일 없음')); return entry; })),
    section('결정과 적용 조건', record.decision?.reason || '외부 에이전트의 결정 대기'));
  if (proof.length > 10) children.push(el('p', 'quiet', `첫 10/${proof.length}개 증거. 에이전트는 research_show로 전체 ID를 조회합니다.`));
  replaceChanged(node, json({record, summary: state.summary, goal: state.goal}), children);
}
function pageText(total, offset, length) { return length ? `${offset + 1}–${offset + length} / ${total}개` : `현재 페이지 0개 / 전체 ${total}개`; }
function drawOverview() {
  const s = status(), rows = s.registrations || [];
  metric('metric-goals', s.goal_total); metric('metric-registrations', s.total); metric('metric-verified', rows.filter((item) => item.verification === 'passed').length); metric('metric-unknown', rows.filter((item) => item.execution === 'unknown').length);
  $('revision-label').textContent = `REV ${s.revision ?? '—'}`;
  $('metric-scope').textContent = `목표·등록은 전체 수 · 검증/미확정은 조회한 ${rows.length}개 기준 · ${pageText(s.total || 0, state.offset, rows.length)}`;
  const list = rows.map((item, index) => { const row = el('article', `registration-row ${item.id === state.selected ? 'selected' : ''}`); row.dataset.registration = item.id;
    const heading = el('div', 'row-heading'); heading.append(el('span', 'row-number', String(state.offset + index + 1).padStart(2, '0')), el('strong', 'mono', item.id));
    const states = el('div', 'state-line'); states.append(...chips(item)); row.append(heading, states); return row; });
  if (!list.length) list.push(el('p', 'quiet', status().total ? '현재 페이지에는 실험이 없습니다 · 전체 등록은 유지되며 에이전트가 다른 페이지를 펼칠 수 있습니다.' : state.workspace ? '등록된 실험 없음 · 에이전트가 조건을 고정하면 흐름이 나타납니다.' : '빈 관전실 · WebMCP 에이전트의 초기화 요청을 기다립니다.'));
  replaceChanged($('registrations-list'), json({rows, selected: state.selected}), list); drawGraph(); drawFocus(); drawEvents();
}
function drawMemory() {
  const data = state.memory, args = state.memoryArgs;
  $('memory-context').textContent = `에이전트 검색 · “${args.query || '전체'}” · 결과 ${labels[args.outcome] || '전체'} · 검증 ${labels[args.verification] || '전체'}`;
  $('memory-page').textContent = data ? pageText(data.total, data.offset, data.items.length) : '검색 결과 대기';
  const rows = (data?.items || []).map((item) => { const card = el('article', 'memory-item'), heading = el('div', 'row-heading'); heading.append(el('h3', '', item.hypothesis), badge(item.outcome));
    const statuses = el('div', 'state-line'); statuses.append(...chips(item), badge(item.claim_verified ? 'verified_claim' : 'unverified', '현재 주장 · '));
    card.append(heading, el('p', '', item.summary), el('small', 'mono', item.id), statuses, el('p', 'quiet', item.reason || '결정 이유 없음'), el('pre', 'memory-conditions', json({conditions: item.conditions, resources: item.resources, evidence_integrity: item.evidence_integrity})), el('small', 'quiet', `${item.evidence_count}개 원본 증거 연결 · 기록 존재와 주장 검증은 별개입니다.`)); return card; });
  if (!rows.length) rows.push(el('h3', '', data ? '조건에 맞는 기록 없음' : '에이전트의 기억 조회 대기'), el('p', 'quiet', '검색 결과가 없다는 사실은 가설의 성공·실패 증거가 아닙니다.'));
  replaceChanged($('memory-results'), json({data, args}), rows);
}
function drawEvidence() {
  const data = state.evidence; $('evidence-title').textContent = data?.evidence?.name || '원본 증거';
  $('evidence-meta').textContent = data ? `${data.evidence.id} · SHA-256 ${data.evidence.sha256} · ${data.bytes} bytes · 해시 확인됨` : '에이전트 조회 대기';
  $('evidence-text').textContent = data?.text ?? '보존된 증거만 조회합니다.'; $('evidence-warning').hidden = !data?.truncated;
  $('evidence-warning').textContent = '큰 원본은 앞부분 256 KiB만 표시했습니다. 보존 원본은 유지됩니다.';
}
function drawEvents() {
  const rows = (state.snapshot?.events || []).map((event) => { const row = el('li', 'event-item'); row.append(el('span', 'event-time', time(event.created)), el('strong', '', eventNames[event.action] || event.action), el('span', 'mono quiet', `${event.target || 'workspace'} · REV ${event.revision}`)); return row; });
  if (!rows.length) rows.push(el('li', 'quiet', '저장된 연구 사건 없음')); replaceChanged($('events-list'), json(state.snapshot?.events || []), rows);
}
function drawCalls() {
  const rows = state.calls.map((call) => { const row = el('li', `call-item ${call.result ? call.result.ok ? 'good' : 'bad' : 'running'}`); row.append(el('span', 'event-time', time(call.created)), el('strong', 'mono', call.tool), el('span', '', call.result ? call.result.ok ? '요청 완료' : errorText(call.result) : '요청 처리 중'), el('small', 'quiet', `${call.workspace} · 외부 에이전트 WebMCP`)); return row; });
  if (!rows.length) rows.push(el('li', 'quiet', '외부 에이전트 도구 호출 대기 · 웹은 스스로 연구하지 않습니다.')); $('calls-list').replaceChildren(...rows);
}
function agentPhase(call, phase) {
  document.body.dataset.phase = phase;
  $('action-status').hidden = false;
  $('action-status').className = `action-status ${phase === 'running' ? 'busy' : phase === 'error' ? 'error' : ''}`;
  $('agent-phase').textContent = phase === 'running' ? 'AGENT REQUEST IN FLIGHT' : phase === 'error' ? 'REQUEST REJECTED' : phase === 'succeeded' ? 'REQUEST COMPLETED' : 'WAITING FOR AGENT';
  $('agent-tool').textContent = call?.tool || '외부 에이전트 연결 대기';
  $('agent-description').textContent = call ? (call.tool === 'research_view' ? '에이전트가 관전 장면을 펼칩니다.' : call.tool === 'research_inspect_evidence' ? '에이전트가 원본 증거를 보여줍니다.' : `${call.workspace}의 연구 도구를 호출했습니다.`) : '데이터를 보고 싶다면 외부 에이전트에게 요청하세요.';
  $('agent-status').textContent = phase === 'running' ? `${state.pending}개 요청 처리 중 · 실제 완료 응답을 기다림` : phase === 'error' ? errorText(call.result) : phase === 'succeeded' ? '현재 도구 요청 완료 · 전체 연구 완료를 뜻하지 않음' : '화면은 관전 전용 · 사람의 입력 조작 없음';
  $('action-status').textContent = call ? `${call.tool} · ${phase === 'running' ? '처리 중' : phase === 'error' ? '거부' : '완료'}` : 'AGENT CONTROL / HUMAN OBSERVATION'; pulseGraph();
}
async function lookupSummary() {
  if (!state.record) return;
  const signature = json([state.workspace, state.selected, status().revision, state.record.evidence.map((item) => [item.id, item.integrity])]);
  const visible = status().registrations.find((item) => item.id === state.selected); if (visible) state.summary = visible;
  const goalId = state.record.registration.goal_id; state.goal = status().goals.find((item) => item.id === goalId) || (state.goal?.id === goalId ? state.goal : null);
  if (visible && state.goal) return;
  if (state.summary && state.summarySignature === signature) return;
  const name = state.workspace, id = state.selected;
  for (let offset = 0; ; offset += 100) {
    const response = await core('research_status', {workspace: name, goal: goalId, limit: 100, offset});
    if (state.workspace !== name || state.selected !== id || !response.ok) return;
    state.goal = response.data.goals.find((item) => item.id === goalId) || state.goal;
    const row = response.data.registrations.find((item) => item.id === id); if (row) { state.summary = row; state.summarySignature = signature; return; }
    if (offset + 100 >= response.data.total) return;
  }
}
async function readSelection() {
  if (!state.selected) return {ok: true}; const name = state.workspace, id = state.selected;
  const result = await core('research_show', {workspace: name, registration: id}); if (name !== state.workspace || id !== state.selected) return result;
  if (result.ok) { state.record = result.data; await lookupSummary(); } else { state.record = null; state.summary = null; notify(errorText(result)); } return result;
}
export async function refresh() {
  const scope = json([state.workspace, state.limit, state.offset, state.selected]);
  if (state.refreshing) {
    if (state.refreshScope === scope) return state.refreshing;
    await state.refreshing;
    return refresh();
  }
  if (!state.workspace) { drawOverview(); return {ok: true}; }
  const name = state.workspace, limit = state.limit, offset = state.offset;
  state.refreshScope = scope;
  state.refreshing = (async () => {
    if (!state.token) { const boot = await ensureSession(); if (!boot.ok) return boot; }
    const result = await request(`/api/snapshot?${qs({workspace: name, limit, offset})}`);
    if (name !== state.workspace || limit !== state.limit || offset !== state.offset) return result;
    if (!result.ok) { notify(errorText(result)); return result; }
    state.snapshot = result.data;
    if (!state.selected && result.data.status.registrations.length) state.selected = result.data.status.registrations[0].id;
    await readSelection();
    // Files can change without a SQLite revision; displayed claims must recheck current integrity.
    if (state.scene === 'memory' && state.memory) { const memory = await core('research_memory', {...state.memoryArgs, workspace: name}); if (memory.ok && name === state.workspace) state.memory = memory.data; }
    if (state.scene === 'evidence' && state.evidence) {
      const evidence = await request(`/api/evidence?${qs({workspace: name, registration: state.selected, evidence: state.evidence.evidence.id})}`);
      if (name === state.workspace && evidence.ok) state.evidence = evidence.data;
      else if (name === state.workspace && !evidence.ok) { state.evidence = null; notify(errorText(evidence)); }
    }
    $('updated-label').textContent = `${time(Date.now() / 1000)} 조회 · 읽기 상태 동기화`;
    drawOverview(); if (state.scene === 'memory') drawMemory(); if (state.scene === 'evidence') drawEvidence(); return result;
  })();
  try { return await state.refreshing; } finally { state.refreshing = null; }
}
function validatePresentation(name, args) {
  const tool = presentationTools.find((item) => item.name === name), properties = tool.inputSchema.properties;
  for (const key of Object.keys(args)) if (!(key in properties)) throw new Error(`Unknown field: ${key}`);
  for (const key of tool.inputSchema.required || []) if (typeof args[key] !== 'string' || !args[key]) throw new Error(`Required text: ${key}`);
  for (const [key, value] of Object.entries(args)) {
    const schema = properties[key], types = Array.isArray(schema.type) ? schema.type : [schema.type];
    if (!types.some((type) => type === 'null' ? value === null : type === 'integer' ? Number.isInteger(value) : typeof value === type)) throw new Error(`Invalid type: ${key}`);
    if (schema.enum && !schema.enum.includes(value)) throw new Error(`Invalid value: ${key}`);
    if (schema.minimum !== undefined && value < schema.minimum || schema.maximum !== undefined && value > schema.maximum) throw new Error(`Out of range: ${key}`);
    if (schema.maxLength && value.length > schema.maxLength) throw new Error(`Too long: ${key}`);
  }
}
async function present(name, args) {
  if (name === 'research_view') {
    state.limit = args.limit ?? PAGE; state.offset = args.offset ?? 0;
    if (args.registration && args.registration !== state.selected) { state.selected = args.registration; state.record = null; state.summary = null; }
    setScene(args.scene || 'overview'); const snapshot = await refresh(); if (!snapshot?.ok) return snapshot;
    if (args.registration && !state.record) return envelopeError('NOT_FOUND', 'Selected registration could not be displayed.');
    if (state.scene === 'memory') {
      state.memoryArgs = {query: args.query ?? '', outcome: args.outcome ?? null, verification: args.verification ?? null, limit: state.limit, offset: state.offset};
      const result = await core('research_memory', {...state.memoryArgs, workspace: state.workspace}); if (!result.ok) return result;
      state.memory = result.data; drawMemory(); return {ok: true, data: {presentation: getViewState(), memory: result.data}};
    }
    return {ok: true, data: {presentation: getViewState(), status: status(), events: state.scene === 'activity' ? state.snapshot.events : undefined}};
  }
  state.selected = args.registration; const selected = await readSelection(); if (!selected.ok) return selected;
  const result = await request(`/api/evidence?${qs({workspace: state.workspace, registration: args.registration, evidence: args.evidence})}`); if (!result.ok) return result;
  state.evidence = result.data; setScene('evidence'); drawEvidence(); drawFocus(); return {ok: true, data: {...result.data, presentation: getViewState()}};
}
/** Native WebMCP is the action entry point. Background refresh only reads. */
export async function executeTool(name, parameters = {}) {
  if (!parameters || typeof parameters !== 'object' || Array.isArray(parameters)) return envelopeError('INVALID_INPUT', 'Arguments must be a JSON object.');
  const isPresentation = presentationTools.some((item) => item.name === name);
  if (!isPresentation && !state.tools.some((item) => item.name === name)) return envelopeError('INVALID_INPUT', 'Unknown page tool.');
  const args = {...parameters, workspace: parameters.workspace ?? (isPresentation ? state.workspace || 'default' : 'default')};
  try { finiteJson(args); if (!relativeWorkspace(args.workspace)) throw new Error('Workspace must be a relative name within the fixed root.'); if (isPresentation) validatePresentation(name, args); }
  catch (error) { return envelopeError('INVALID_INPUT', error.message); }
  const boot = await ensureSession(); if (!boot.ok) return boot;
  const call = {id: ++state.serial, tool: name, workspace: args.workspace, created: new Date().toISOString(), result: null};
  state.latest = call.id; state.calls.unshift(call); state.calls = state.calls.slice(0, 30); state.pending++;
  workspace(args.workspace); state.explanation = isPresentation ? args.explanation || '' : '';
  if (!isPresentation) setScene(name === 'research_memory' ? 'memory' : ['research_help', 'research_export', 'research_restore', 'research_laya_prepare', 'research_laya_resolve'].includes(name) ? 'activity' : 'overview');
  if (args.registration && state.selected !== args.registration) { state.selected = args.registration; state.record = null; state.summary = null; }
  notify(); drawOverview(); drawCalls(); agentPhase(call, 'running'); let result;
  try {
    result = isPresentation ? await present(name, args) : await core(name, args);
    if (result.ok && state.latest === call.id && state.workspace === args.workspace && !isPresentation) {
      const data = result.data;
      if (name === 'research_status') { state.limit = args.limit ?? PAGE; state.offset = args.offset ?? 0; }
      if (name === 'research_memory') { state.memory = data; state.memoryArgs = {query: args.query || '', outcome: args.outcome || null, verification: args.verification || null, limit: args.limit ?? PAGE, offset: args.offset ?? 0}; drawMemory(); }
      const record = data?.registration?.spec && data?.hypothesis ? data : null;
      const registration = record?.registration?.id || data?.record?.registration?.id || (name === 'research_register' ? data?.registration?.id : null) || args.registration;
      if (registration) { state.selected = registration; state.record = record; state.summary = null; }
      if (name === 'research_register' && !data.reused) state.offset = Math.floor((status().total || 0) / state.limit) * state.limit;
      if (name !== 'research_help') await refresh();
    }
  } catch (error) { result = envelopeError('CLIENT_ERROR', error.message); }
  call.result = result; state.pending--;
  if (result.ok && result.data?.presentation) result.data.presentation = getViewState();
  drawCalls();
  if (state.latest === call.id) { if (!result.ok) notify(errorText(result)); agentPhase(call, result.ok ? 'succeeded' : 'error'); } return result;
}
async function registerNativeTools() {
  const list = [...state.tools, ...presentationTools], node = $('webmcp-status');
  if (typeof document.modelContext?.registerTool !== 'function') { node.textContent = 'WebMCP 미지원 · 관전만 가능'; notify('이 브라우저에서는 에이전트의 웹 제어를 사용할 수 없습니다. 네이티브 WebMCP 지원 브라우저에서 이 페이지를 여세요. CLI 상태 변화는 계속 관전합니다.'); return; }
  let count = 0; const failures = [];
  for (const tool of list) { try { await document.modelContext.registerTool({name: tool.name, description: tool.description, inputSchema: tool.inputSchema, annotations: {readOnlyHint: Boolean(tool.annotations?.readOnlyHint)}, execute: async (args) => executeTool(tool.name, args || {})}); count++; } catch (error) { failures.push(`${tool.name}: ${error.message}`); } }
  node.textContent = `NATIVE WebMCP · ${count}/${list.length}`; node.dataset.state = count === list.length ? 'connected' : 'partial'; if (failures.length) notify(failures.join(' · '));
}
async function autoSelectWorkspace() {
  const result = await request(`/api/workspaces?${qs({limit: PAGE, offset: 0})}`); if (!result.ok) return;
  let saved = ''; try { saved = localStorage.getItem('research-state-workspace') || ''; } catch (_) { /* Optional only. */ }
  const items = result.data.items || [], preferred = items.find((item) => item.name === saved) || [...items].sort((a, b) => b.revision - a.revision)[0]; if (preferred) workspace(preferred.name);
}
async function start() {
  document.body.dataset.phase = 'idle'; setScene('overview'); agentPhase(null, 'idle'); drawOverview(); drawMemory(); drawCalls();
  const result = await ensureSession();
  if (result.ok) { state.tools = result.data.tools; await autoSelectWorkspace(); await refresh(); await registerNativeTools(); state.booted = true; }
  else { notify(errorText(result)); $('webmcp-status').textContent = 'WebMCP · 서버 연결 대기'; }
  // No automatic init, run, recovery mutation, verification, scientific choice, or model call.
  setInterval(async () => {
    if (document.visibilityState === 'hidden') return;
    if (!state.booted) { const boot = await ensureSession(); if (!boot.ok) return; state.tools = boot.data.tools; await autoSelectWorkspace(); await registerNativeTools(); state.booted = true; }
    if (!state.workspace) await autoSelectWorkspace(); await refresh();
  }, 2000);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') refresh(); });
  window.addEventListener('resize', drawGraph);
}
start();
