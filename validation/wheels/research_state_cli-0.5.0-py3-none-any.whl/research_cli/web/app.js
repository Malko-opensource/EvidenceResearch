/* Two visible channels share the CLI's existing state transitions. */
const $ = (id) => document.getElementById(id);
const PAGE = 20;
const state = {token: null, tools: [], workspace: '', workspaceOffset: 0, workspaceTotal: 0,
  offset: 0, objectiveOffset: 0, objectives: null, snapshot: null, selected: '', record: null, detailTab: 'overview', view: 'overview',
  memory: null, selectedStatus: null, selectedStatusRevision: null,
  memoryArgs: {query: '', outcome: null, verification: null, limit: PAGE, offset: 0},
  calls: [], pending: 0, refreshPromise: null, runKeys: new Map(), lastSnapshot: '', lastDetail: '', connected: false};
const titles = {overview: ['연구 흐름', '현재 상태에서 원본 증거까지, 연구의 흐름을 함께 확인하세요.'],
  memory: ['연구 기억', '성공, 실패와 미결 결과를 조건과 검증 상태로 찾아봅니다.'],
  tools: ['연구 기록·도구', '외부 에이전트의 제안과 판단을 고정된 연구 상태에 연결합니다.'],
  activity: ['활동 기록', '같은 저장소의 변경과 이 화면의 도구 호출을 함께 확인합니다.']};
const labels = {registered: '사전등록', running: '실행 중', succeeded: '실행 성공', failed: '실패',
  unknown: '실행 미확정', pending: '대기', passed: '검증 통과', adopted: '채택', rejected: '기각',
  inconclusive: '미결', valid: '해시 일치', invalid: '증거 무결성 문제', tampered: '변조 감지', missing: '파일 누락',
  no_file: '원본 파일 없음', measured: '측정값', literature: '문헌 주장', inference: '추론', proposal: '미실행 제안',
  success: '성공', failure: '실패', goal: '목표 기록', hypothesis: '가설 기록', register: '사전등록',
  run: '실행', recover: '실행 확인·복구', verify: '독립 검증', decide: '결정 기록', evidence: '증거 추가',
  show: '원본 상세', memory: '기억 검색'};
const missingLabels = {'execution receipt': '실행 완료 영수증', 'verified artifact metrics': '검증된 산출물 지표',
  'confirmed terminal execution receipt': '실행 여부와 종료를 확인할 영수증', 'independent verification': '독립 검증 결과'};
const eventLabels = {'goal.create': '연구 목표 기록', 'hypothesis.create': '가설 제안 기록',
  'validator.register': '검증기 고정', 'registration.create': '실험 사전등록', 'run.claim': '실행 요청 확보',
  'run.complete': '실행 증거 수집', 'run.unknown': '실행 여부 미확정', 'verification.complete': '독립 검증 완료',
  'decision.create': '연구 결정 기록', 'evidence.add': '증거 연결'};

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined && text !== null) node.textContent = String(text);
  return node;
}
function button(text, className, callback) {
  const node = el('button', className, text); node.type = 'button';
  if (callback) node.addEventListener('click', callback);
  return node;
}
function tone(value) {
  if (['succeeded', 'passed', 'adopted', 'valid', 'success'].includes(value)) return 'good';
  if (['running', 'unknown', 'inconclusive'].includes(value)) return 'warn';
  if (['failed', 'rejected', 'invalid', 'tampered', 'missing', 'failure'].includes(value)) return 'bad';
  return '';
}
function chip(value, prefix = '') { return el('span', `chip ${tone(value)}`, prefix + (labels[value] || value || '—')); }
function stateChips(execution, verification, decision) {
  return [chip(execution, execution === 'failed' ? '실행 ' : ''),
    chip(verification, verification === 'passed' ? '' : '검증 '),
    chip(decision, ['pending', 'inconclusive'].includes(decision) ? '결정 ' : '')];
}
function json(value) { return JSON.stringify(value, null, 2); }
function time(value, full = false) {
  if (!value) return '—';
  const date = new Date(typeof value === 'number' ? value * 1000 : value);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat('ko-KR', {timeZone: 'Asia/Seoul', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', ...(full ? {year: 'numeric', second: '2-digit'} : {})}).format(date);
}
function empty(container, title, description, action) {
  const box = el('div', 'empty-state'); box.append(el('h3', '', title), el('p', '', description));
  if (action) box.append(action); container.replaceChildren(box);
}
function notify(message, type = '') {
  $('notice').textContent = message; $('notice').className = `notice ${type}`; $('notice').hidden = !message;
}
function setConnection(online) {
  state.connected = online;
  const badge = $('connection-status'); badge.className = `badge ${online ? 'live' : 'error'}`;
  badge.replaceChildren(el('span', 'dot'), document.createTextNode(online ? '로컬 저장소 연결' : '연결 확인 필요'));
}
async function request(path, options = {}) {
  try {
    const response = await fetch(path, {cache: 'no-store', credentials: 'same-origin', ...options});
    const result = await response.json();
    if (!result || typeof result.ok !== 'boolean') throw new Error('서버 응답 형식을 확인할 수 없습니다.');
    setConnection(true);
    return result;
  } catch (error) {
    setConnection(false);
    return {ok: false, error: {code: 'CONNECTION_ERROR', message: error.message || '서버에 연결할 수 없습니다.', details: {}}};
  }
}
function errorText(envelope) { return `${envelope.error?.code || 'ERROR'} · ${envelope.error?.message || '작업을 완료하지 못했습니다.'}`; }
function queryString(values) { return new URLSearchParams(Object.entries(values).filter(([, value]) => value !== null && value !== undefined)).toString(); }
function currentStatus() { return state.snapshot?.status || {goals: [], hypotheses: [], registrations: [], revision: null}; }
function selectedSummary() {
  return currentStatus().registrations?.find((item) => item.id === state.selected)
    || (state.selectedStatus?.id === state.selected ? state.selectedStatus : null);
}

export function getViewState() {
  return {workspace: state.workspace, view: state.view, selectedRegistration: state.selected,
    revision: currentStatus().revision, pendingCalls: state.pending, connected: state.connected};
}
export function setView(view, loadMemory = true) {
  if (!titles[view]) return;
  state.view = view;
  document.querySelectorAll('.view').forEach((node) => { node.hidden = node.id !== `view-${view}`; });
  document.querySelectorAll('[data-view]').forEach((node) => {
    const active = node.dataset.view === view; node.classList.toggle('active', active);
    if (active) node.setAttribute('aria-current', 'page'); else node.removeAttribute('aria-current');
  });
  $('page-title').textContent = titles[view][0]; $('page-description').textContent = titles[view][1];
  if (view === 'memory' && loadMemory && !state.memory && state.workspace) searchMemory();
}
function setForm(name) {
  setView('tools');
  document.querySelectorAll('.form-tabs [data-form]').forEach((node) => {
    const selected = node.dataset.form === name;
    node.classList.toggle('active', selected); node.setAttribute('aria-selected', String(selected));
  });
  ['goal', 'hypothesis', 'register', 'evidence', 'decide'].forEach((value) => { $(`${value}-form`).hidden = value !== name; });
  if (state.selected) document.querySelectorAll('.registration-input').forEach((node) => { if (!node.value) node.value = state.selected; });
}
function setWorkspace(name) {
  if (state.workspace === name) return;
  state.workspace = name; state.offset = 0; state.objectiveOffset = 0; state.objectives = null;
  state.snapshot = null; state.selected = ''; state.record = null;
  state.selectedStatus = null; state.selectedStatusRevision = null;
  state.memory = null; state.lastSnapshot = ''; state.lastDetail = ''; state.memoryArgs.offset = 0;
  $('workspace-name').textContent = name || '작업공간 선택';
  const select = $('workspace-select');
  if (name && !Array.from(select.options).some((option) => option.value === name)) select.add(new Option(name, name));
  select.value = name;
  try { localStorage.setItem('research-state-workspace', name); } catch (_) { /* Storage may be disabled. */ }
  renderSnapshot(); renderDetail(); renderMemory();
}
async function loadWorkspaces(selectFirst = false) {
  const response = await request(`/api/workspaces?${queryString({limit: PAGE, offset: state.workspaceOffset})}`);
  if (!response.ok) { notify(errorText(response), 'error'); return; }
  const data = response.data, items = data.items || data.workspaces || [];
  state.workspaceTotal = data.total || 0;
  const select = $('workspace-select');
  const options = [new Option(state.workspaceTotal ? '작업공간 선택' : '아직 작업공간이 없습니다', '')];
  items.forEach((item) => { const name = typeof item === 'string' ? item : (item.name || item.workspace); if (name) options.push(new Option(name, name)); });
  if (state.workspace && !options.some((option) => option.value === state.workspace)) options.push(new Option(state.workspace, state.workspace));
  select.replaceChildren(...options); select.value = state.workspace;
  $('workspace-count').textContent = `${state.workspaceTotal}개 작업공간`;
  $('workspaces-prev').disabled = state.workspaceOffset === 0;
  $('workspaces-next').disabled = state.workspaceOffset + PAGE >= state.workspaceTotal;
  if (selectFirst && !state.workspace && items.length) {
    let saved = ''; try { saved = localStorage.getItem('research-state-workspace') || ''; } catch (_) { /* Optional preference only. */ }
    const names = options.map((item) => item.value);
    setWorkspace(names.includes(saved) && saved ? saved : names.find((name) => name) || '');
  }
}
function updateGoalSelects(goals) {
  document.querySelectorAll('.goal-select').forEach((node) => {
    const signature = json(goals.map((goal) => [goal.id, goal.title]));
    if (node.dataset.signature === signature || document.activeElement === node) return;
    const chosen = node.value; node.replaceChildren(new Option('연구 목표 선택', ''));
    goals.forEach((goal) => node.add(new Option(goal.title, goal.id)));
    node.value = goals.some((goal) => goal.id === chosen) ? chosen : (goals.length === 1 ? goals[0].id : '');
    node.dataset.signature = signature;
  });
}
function renderSnapshot() {
  const status = currentStatus(), rows = status.registrations || [];
  $('count-goals').textContent = status.goal_total || 0;
  $('count-registrations').textContent = status.total || 0;
  $('count-verified').textContent = rows.filter((item) => item.verification === 'passed').length;
  $('count-unknown').textContent = rows.filter((item) => item.execution === 'unknown').length;
  $('registration-total').textContent = status.total || 0;
  $('nav-registration-count').textContent = status.total || 0;
  $('revision-label').textContent = `REV ${status.revision ?? '—'}`;
  $('registrations-prev').disabled = state.offset === 0;
  $('registrations-next').disabled = state.offset + PAGE >= (status.total || 0);
  $('registration-page').textContent = pageText(status.total || 0, state.offset, rows.length);
  const list = $('registrations-list');
  if (!rows.length) {
    empty(list, state.workspace ? '사전등록된 실험이 없습니다' : '연구 작업공간을 선택하세요',
      state.workspace ? '목표와 가설을 기록하고 조건을 고정하면 실험의 흐름이 여기에 나타납니다.' : '왼쪽에서 기존 작업공간을 선택하거나 새 작업공간을 만드세요.',
      state.workspace ? button('＋ 목표부터 기록', 'button secondary', () => setForm('goal')) : null);
  } else {
    list.replaceChildren(...rows.map((item, index) => {
      const row = button('', `registration-row ${item.id === state.selected ? 'selected' : ''}`, () => selectRegistration(item.id));
      row.dataset.registration = item.id; row.setAttribute('aria-label', `${item.id} ${labels[item.execution] || item.execution} 상세`);
      row.setAttribute('aria-pressed', String(item.id === state.selected));
      const copy = el('span'); copy.append(el('span', 'registration-title', `실험 ${String(state.offset + index + 1).padStart(2, '0')}`), el('span', 'registration-id', item.id));
      const badges = el('span', 'registration-states'); badges.append(...stateChips(item.execution, item.verification, item.decision));
      row.append(el('span', 'registration-symbol', '↗'), copy, badges); return row;
    }));
  }
  const objectives = $('objectives-list'), objectiveState = state.objectives || status;
  const goals = objectiveState.goals || [], hypotheses = objectiveState.hypotheses || [];
  $('objectives-total').textContent = `전체 목표 ${status.goal_total || 0}개 · 가설 ${status.hypothesis_total || 0}개 / 현재 페이지`;
  $('objectives-page').textContent = goals.length ? `${state.objectiveOffset + 1}–${state.objectiveOffset + goals.length} / ${status.goal_total || 0}개 목표` : '현재 페이지에 목표 없음';
  $('objectives-prev').disabled = state.objectiveOffset === 0;
  $('objectives-next').disabled = state.objectiveOffset + PAGE >= Math.max(status.goal_total || 0, status.hypothesis_total || 0);
  if (!goals.length) empty(objectives, status.goal_total ? '현재 페이지에 목표가 없습니다' : '아직 기록된 목표가 없습니다', '연구할 문제와 적용 조건을 외부 에이전트 또는 사용자가 기록합니다.');
  else objectives.replaceChildren(...goals.map((goal) => {
    const box = el('article', 'objective'), heading = el('div', 'objective-title');
    heading.append(el('h3', '', goal.title), button('＋ 가설', 'text-button', () => { setForm('hypothesis'); $('hypothesis-goal').value = goal.id; }));
    box.append(heading, el('p', '', goal.description || '배경 설명이 기록되지 않았습니다.'), el('div', 'objective-id mono', goal.id));
    hypotheses.filter((item) => item.goal_id === goal.id).forEach((item) => {
      const text = el('div'); text.append(el('span', '', item.statement), el('small', 'mono', item.id));
      const node = el('div', 'hypothesis'); node.append(el('span', '', '↳'), text); box.append(node);
    }); return box;
  }));
  const visibleGoals = new Set(goals.map((goal) => goal.id));
  hypotheses.filter((item) => !visibleGoals.has(item.goal_id)).forEach((item) => {
    const box = el('article', 'objective');
    box.append(el('span', 'eyebrow', '현재 페이지의 가설 · 다른 목표 페이지'), el('h3', '', item.statement),
      el('div', 'objective-id mono', `목표 ${item.goal_id}`), el('div', 'objective-id mono', item.id));
    objectives.append(box);
  });
  updateGoalSelects(goals); renderWorkflow(); renderEvents();
}
function renderWorkflow() {
  const summary = selectedSummary(), record = state.record;
  const selected = Boolean(summary || record), execution = record?.run?.state || summary?.execution || 'registered';
  const verification = record?.verification?.state || summary?.verification || 'pending';
  const decision = record?.decision?.state || summary?.decision || 'pending';
  const status = currentStatus();
  const stages = [
    ['목표', '01', selected || (status.goals?.length > 0) ? 'complete' : '', selected ? '등록 목표 연결' : `${status.goal_total || 0}개 기록`, 'overview'],
    ['가설', '02', selected || (status.hypotheses?.length > 0) ? 'complete' : '', selected ? '가설 연결' : `${status.hypothesis_total || 0}개 제안`, 'overview'],
    ['사전등록', '03', selected ? 'complete' : '', selected ? '조건 고정' : '실험 선택 전', 'criteria'],
    ['실행', '04', !selected || execution === 'registered' ? '' : execution === 'succeeded' ? 'complete' : execution === 'failed' ? 'error' : execution === 'unknown' ? 'warn' : 'active', selected ? labels[execution] : '실험 선택 전', 'overview'],
    ['검증', '05', !selected || verification === 'pending' ? '' : verification === 'passed' ? 'complete' : verification === 'failed' ? 'error' : 'warn', selected ? (verification === 'pending' ? '검증 대기' : labels[verification]) : '실험 선택 전', 'criteria'],
    ['결정', '06', !selected || decision === 'pending' ? '' : decision === 'adopted' ? 'complete' : decision === 'rejected' ? 'error' : 'warn', selected ? (decision === 'pending' ? '결정 대기' : labels[decision]) : '실험 선택 전', 'overview']
  ];
  $('workflow').replaceChildren(...stages.map(([name, number, style, text, tab]) => {
    const node = button('', `flow-node ${style}`, () => {
      if (selected) { state.detailTab = tab; renderDetail(true); $('detail-panel').scrollIntoView({block: 'nearest', behavior: 'auto'}); }
      else if (state.workspace) setForm(name === '목표' ? 'goal' : name === '가설' ? 'hypothesis' : 'register');
    });
    node.dataset.stage = name; node.append(el('span', 'node-icon', style === 'complete' ? '✓' : style === 'warn' ? '?' : style === 'error' ? '!' : number), el('span', 'node-label', name), el('span', 'node-state', text));
    node.setAttribute('aria-label', `${name}: ${text}`); return node;
  }));
  $('flow-context').textContent = selected ? `선택한 실험 · ${state.selected.slice(-8)}` : '실험을 선택하면 상태를 보여줍니다';
  $('flow-note').textContent = execution === 'unknown' && selected
    ? '실행 여부가 미확정입니다. recover로 영수증을 확인하세요. 반복 실행 요청은 새 실행을 시작하지 않습니다.'
    : '실행 성공, 검증 통과, 가설 채택은 각각 다른 상태입니다.';
}
function section(title, content) {
  const node = el('section', 'detail-section'); node.append(el('span', 'detail-label', title));
  if (Array.isArray(content)) node.append(...content); else if (typeof content === 'string') node.append(el('p', '', content)); else if (content) node.append(content);
  return node;
}
function dataGrid(entries) {
  const grid = el('dl', 'data-grid');
  entries.forEach(([key, value]) => { const box = el('div'); box.append(el('dt', '', key), el('dd', '', value ?? 'unknown')); grid.append(box); });
  return grid;
}
function resources(resources = {}) {
  return Object.entries(resources).map(([key, value]) => {
    if (value && typeof value === 'object') return [key, value.status === 'unknown' ? 'unknown · 확인 불가' : value.value ?? json(value)];
    return [key, value];
  });
}
function renderDetail(force = false) {
  const panel = $('detail-panel'), record = state.record;
  if (!record || record.registration?.id !== state.selected) {
    if (state.selected) empty(panel, '실험 상세 조회 중', state.selected);
    else { const box = el('div', 'detail-empty'); box.append(el('span', 'empty-symbol', '↗'), el('h2', '', '흐름을 증거와 연결하세요'), el('p', '', '실험 기록을 선택하면 고정된 조건, 검증 결과, 원본 로그와 남은 작업을 확인할 수 있습니다.'), el('span', 'quiet', '기록은 실제 저장소에서 조회합니다')); panel.replaceChildren(box); }
    return;
  }
  if (!force && panel.contains(document.activeElement) && ['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) return;
  const spec = record.registration.spec, execution = record.run?.state || 'registered', verification = record.verification?.state || 'pending', decision = record.decision?.state || 'pending';
  const heading = el('div', 'detail-heading'); heading.append(el('span', 'eyebrow', 'SELECTED EXPERIMENT'), el('div', 'mono', record.registration.id), el('h2', '', spec.change));
  const badges = el('div', 'detail-badges'); badges.append(...stateChips(execution, verification, decision)); heading.append(badges);
  const tabs = el('div', 'detail-tabs'); [['overview', '상태'], ['criteria', '고정 조건'], ['evidence', '원본 증거'], ['record', '전체 기록']].forEach(([key, title]) => {
    const tab = button(title, state.detailTab === key ? 'active' : '', () => { state.detailTab = key; renderDetail(true); });
    tab.dataset.detailTab = key; tab.setAttribute('aria-pressed', String(state.detailTab === key)); tabs.append(tab);
  });
  const sections = [];
  if (state.detailTab === 'overview') {
    sections.push(section('가설', record.hypothesis?.statement || '가설 연결 확인 필요'));
    const summary = selectedSummary();
    const missing = summary?.missing_evidence || [];
    if (missing.length) { const list = el('ul', 'missing-list'); missing.forEach((item) => list.append(el('li', '', missingLabels[item] || item))); sections.push(section('부족한 증거', list)); }
    sections.push(section('현재 허용된 작업', actionButtons(summary?.allowed_actions || ['show', 'memory', 'evidence'])));
    if (record.run) {
      sections.push(section('실행 기록', dataGrid([['실행 ID', record.run.id], ['시작', time(record.run.created, true)], ['종료', time(record.run.finished, true)], ['오류·미확정 원인', record.run.reason || record.run.receipt?.error || '—']])));
      sections.push(section('자원 사용', dataGrid(resources(record.run.resources))));
    } else sections.push(section('자원 사용', '아직 실행하지 않았습니다. 외부 에이전트의 모델·토큰 사용량은 별도 측정이 필요합니다.'));
    if (record.verification) sections.push(section('검증 지표', dataGrid(Object.entries(record.verification.metrics || {}))));
    if (record.decision.reason) sections.push(section('결정 이유', record.decision.reason));
  } else if (state.detailTab === 'criteria') {
    sections.push(section('변경점·비교 대상', [el('p', '', spec.change), el('p', '', `비교: ${spec.comparison}`)]));
    const criteria = el('div'); (spec.criteria || []).forEach((item) => { const row = el('div', 'criteria-row'); row.append(el('strong', '', item.metric), el('span', '', `${item.op} ${item.threshold}`)); criteria.append(row); });
    sections.push(section('실행 전에 고정한 성공 기준', criteria));
    sections.push(section('데이터 분할·seed', [dataGrid([['seed', spec.seed], ['검증기', spec.validator]]), el('pre', 'detail-json', json(spec.data_split))]));
    sections.push(section('소스 버전·해시', el('pre', 'detail-json', json(spec.source_version))));
    sections.push(section('실행 조건', el('pre', 'detail-json', json({command: spec.command, cwd: spec.cwd, artifacts: spec.artifacts, validator_sha256: spec.validator_sha256}))));
    if (record.verification) sections.push(section('검증 결과 원본', el('pre', 'detail-json', json(record.verification))));
  } else if (state.detailTab === 'evidence') {
    const items = record.evidence || [];
    if (!items.length) sections.push(section('원본 증거', '아직 연결된 증거가 없습니다. 실행 로그·산출물은 실제 실행 후 보존됩니다.'));
    else {
      const list = el('div'); items.forEach((item) => {
        const box = el('article', 'evidence-item'), top = el('div', 'evidence-top');
        top.append(el('strong', '', item.name || labels[item.kind] || item.id), chip(item.integrity));
        const badges = el('div', 'detail-badges'); badges.append(chip(item.kind), el('span', `chip ${item.verified ? 'good' : ''}`, item.verified ? '검증된 측정 증거' : '주장 미검증'));
        box.append(top, el('p', '', item.claim || '실행에서 수집된 원본'), badges, el('div', 'evidence-hash mono', item.sha256 ? `SHA-256 ${item.sha256}` : '원본 파일 해시 없음'));
        if (item.path) { box.append(el('div', 'evidence-hash mono', item.path)); const open = button('원본 로그·산출물 보기 ↗', 'text-button', () => openEvidence(item)); open.dataset.evidence = item.id; box.append(open); }
        list.append(box);
      }); sections.push(section('보존된 증거와 현재 무결성', list));
    }
  } else sections.push(section('연구 등록·영수증·검증·결정 원본', el('pre', 'detail-json', json(record))));
  panel.replaceChildren(heading, tabs, ...sections);
}
function actionButtons(allowed) {
  const container = el('div'), buttons = el('div', 'action-buttons');
  if (allowed.includes('run')) {
    const label = el('label', 'detail-label', '실행 요청 식별자'), input = el('input');
    input.id = 'run-request-key'; input.value = state.runKeys.get(state.selected) || `web-run-${state.selected}`;
    input.setAttribute('aria-label', '실행 요청 식별자'); input.addEventListener('input', () => state.runKeys.set(state.selected, input.value));
    input.className = 'mono'; container.append(label, input); buttons.classList.add('with-input');
  }
  allowed.filter((action) => !['show'].includes(action)).forEach((action) => {
    const node = button(labels[action] || action, `button ${['run', 'verify'].includes(action) ? 'primary' : 'secondary'} compact`, () => {
      if (['evidence', 'decide'].includes(action)) { setForm(action); $(`${action}-registration`).value = state.selected; return; }
      if (action === 'memory') { setView('memory'); return; }
      const args = {registration: state.selected};
      if (action === 'run') { args.request_key = $('run-request-key')?.value || state.runKeys.get(state.selected) || `web-run-${state.selected}`; args.expect = currentStatus().revision; }
      executeTool(`research_${action}`, args);
    }); node.dataset.tool = `research_${action}`; buttons.append(node);
  });
  container.append(buttons, el('p', 'detail-actions-note', '허용된 작업과 부족한 증거를 표시합니다. 어떤 가설을 채택할지는 외부에서 판단합니다.'));
  return container;
}
export async function selectRegistration(id) {
  state.selected = id; state.record = null; state.selectedStatus = null; state.selectedStatusRevision = null;
  state.lastDetail = ''; state.detailTab = 'overview';
  setView('overview'); renderSnapshot(); renderDetail();
  document.querySelectorAll('.registration-input').forEach((node) => { node.value = id; });
  const workspace = state.workspace;
  const result = await request('/api/call', {method: 'POST', headers: {'Content-Type': 'application/json', 'X-Research-Session': state.token}, body: json({tool: 'research_show', arguments: {workspace, registration: id}})});
  if (workspace !== state.workspace || id !== state.selected) return;
  if (result.ok) { state.record = result.data; state.lastDetail = json(result.data); await lookupSelectedSummary(); renderDetail(true); renderWorkflow(); }
  else { notify(errorText(result), 'error'); empty($('detail-panel'), '실험 상세를 읽지 못했습니다', errorText(result)); }
}
async function lookupSelectedSummary() {
  const id = state.selected, workspace = state.workspace, revision = currentStatus().revision;
  const visible = currentStatus().registrations?.find((item) => item.id === id);
  if (visible) { state.selectedStatus = visible; state.selectedStatusRevision = revision; return; }
  if (!id || !state.record?.registration?.goal_id || (state.selectedStatus?.id === id && state.selectedStatusRevision === revision)) return;
  // Off-page selection uses the core's paginated descriptions; it does not infer transitions.
  const goal = state.record.registration.goal_id;
  for (let offset = 0; ; offset += 100) {
    const result = await request('/api/call', {method: 'POST', headers: {'Content-Type': 'application/json', 'X-Research-Session': state.token},
      body: json({tool: 'research_status', arguments: {workspace, goal, limit: 100, offset}})});
    if (workspace !== state.workspace || id !== state.selected || !result.ok) return;
    const found = result.data.registrations.find((item) => item.id === id);
    if (found) { state.selectedStatus = found; state.selectedStatusRevision = revision; return; }
    if (offset + 100 >= result.data.total) { state.selectedStatus = null; state.selectedStatusRevision = revision; return; }
  }
}
export async function refresh() {
  if (!state.workspace) { renderSnapshot(); return; }
  if (state.refreshPromise) return state.refreshPromise;
  const workspace = state.workspace, offset = state.offset;
  state.refreshPromise = (async () => {
    const result = await request(`/api/snapshot?${queryString({workspace, limit: PAGE, offset})}`);
    if (workspace !== state.workspace || offset !== state.offset) return;
    if (!result.ok) { notify(errorText(result), 'error'); return; }
    let objectiveState = result.data.status;
    if (state.objectiveOffset !== offset) {
      const objectives = await request('/api/call', {method: 'POST', headers: {'Content-Type': 'application/json', 'X-Research-Session': state.token},
        body: json({tool: 'research_status', arguments: {workspace, limit: PAGE, offset: state.objectiveOffset}})});
      if (objectives.ok) objectiveState = objectives.data;
    }
    if (workspace !== state.workspace || offset !== state.offset) return;
    state.objectives = objectiveState;
    const signature = json(result.data), changed = signature !== state.lastSnapshot;
    if (signature !== state.lastSnapshot) { state.snapshot = result.data; state.lastSnapshot = signature; renderSnapshot(); }
    else if (json(state.objectives) !== $('objectives-list').dataset.signature) renderSnapshot();
    $('objectives-list').dataset.signature = json(state.objectives);
    $('updated-label').textContent = `${time(new Date().toISOString())} 조회 · 2초마다 반영`;
    if (state.selected) {
      const id = state.selected;
      const detail = await request('/api/call', {method: 'POST', headers: {'Content-Type': 'application/json', 'X-Research-Session': state.token}, body: json({tool: 'research_show', arguments: {workspace, registration: id}})});
      if (workspace !== state.workspace || id !== state.selected) return;
      if (detail.ok && json(detail.data) !== state.lastDetail) { state.record = detail.data; state.lastDetail = json(detail.data); await lookupSelectedSummary(); renderDetail(); renderWorkflow(); }
      else if (detail.ok) await lookupSelectedSummary();
    }
    if (changed && state.view === 'memory' && state.memory && state.memory.revision !== currentStatus().revision) {
      const args = {...state.memoryArgs};
      const memory = await request('/api/call', {method: 'POST', headers: {'Content-Type': 'application/json', 'X-Research-Session': state.token}, body: json({tool: 'research_memory', arguments: {...args, workspace}})});
      if (memory.ok && workspace === state.workspace) { state.memory = memory.data; renderMemory(); }
    }
  })();
  try { await state.refreshPromise; } finally { state.refreshPromise = null; }
}
function pageText(total, offset, size) { return total ? `${offset + 1}–${offset + size} / ${total}개 기록` : '0개 기록'; }
function renderMemory() {
  const data = state.memory, list = $('memory-results');
  if (!data || !data.items?.length) empty(list, data ? '조건에 맞는 기록이 없습니다' : '연구 기억을 검색하세요', '결과가 없다는 것은 가설이 맞거나 틀렸다는 증거가 아닙니다. 검색 조건과 적용 범위를 확인하세요.');
  else list.replaceChildren(...data.items.map((item) => {
    const node = el('article', 'memory-item'), top = el('div', 'memory-item-top');
    top.append(el('h3', '', item.hypothesis), chip(item.outcome));
    const badges = el('div', 'detail-badges'); badges.append(...stateChips(item.execution, item.verification, item.decision), el('span', `chip ${item.claim_verified ? 'good' : 'warn'}`, item.claim_verified ? '현재 증거로 주장 검증됨' : '주장 검증 확인 필요'));
    node.append(top, el('p', '', item.summary), el('div', 'registration-id', item.id), badges);
    if (item.reason) node.append(el('p', '', `결정 이유: ${item.reason}`));
    const conditions = el('details', 'schema-details'); conditions.append(el('summary', '', '적용 조건·자원 확인'), el('pre', '', json({conditions: item.conditions, resources: item.resources, evidence_integrity: item.evidence_integrity})));
    const footer = el('div', 'memory-footer'); footer.append(el('span', 'quiet', `${item.evidence_count}개 증거 · 원본 상세에서 검증 여부 확인`), button('실험·원본 증거 보기 ↗', 'text-button', () => selectRegistration(item.id)));
    node.append(conditions, footer); return node;
  }));
  $('memory-page').textContent = data ? pageText(data.total, data.offset, data.items?.length || 0) : '검색 전';
  $('memory-prev').disabled = !data || data.offset === 0; $('memory-next').disabled = !data || data.offset + PAGE >= data.total;
}
async function searchMemory(offset = state.memoryArgs.offset, limit = state.memory?.limit || PAGE) {
  if (!state.workspace) { notify('작업공간을 먼저 선택하세요.'); return; }
  state.memoryArgs = {query: $('memory-query').value, outcome: $('memory-outcome').value || null,
    verification: $('memory-verification').value || null, limit, offset};
  return executeTool('research_memory', state.memoryArgs, {source: '사용자', reveal: false});
}
function renderEvents() {
  $('event-total').textContent = state.snapshot?.event_total || 0;
  const events = state.snapshot?.events || [], list = $('events-list');
  if (!events.length) { empty(list, '저장된 활동이 없습니다', '상태를 변경하면 실제 연구 이벤트가 여기에 나타납니다.'); return; }
  list.replaceChildren(...events.map((item) => {
    const row = el('li', 'event-item'), content = el('div', 'event-content');
    content.append(el('strong', '', eventLabels[item.action] || item.action), el('small', 'mono', item.target || '작업공간'), el('small', '', `REV ${item.revision} · ${item.action}`));
    const date = el('time', '', time(item.created)); date.dateTime = new Date(item.created * 1000).toISOString();
    row.append(el('span', 'event-dot', '✓'), content, date); return row;
  }));
}
function renderCalls() {
  const list = $('calls-list');
  if (!state.calls.length) { empty(list, '화면 도구 호출이 없습니다', '사람의 작업과 WebMCP 호출은 같은 함수로 처리되어 결과가 화면에 표시됩니다.'); return; }
  list.replaceChildren(...state.calls.map((item) => {
    const row = el('li', 'call-item'), top = el('div', 'call-top');
    top.append(el('strong', 'mono', item.tool), el('span', `chip ${item.result ? item.result.ok ? 'good' : 'bad' : 'warn'}`, item.result ? item.result.ok ? '완료' : '오류' : '진행 중'));
    row.append(top, el('div', 'call-meta', `${item.source} · ${item.workspace} · ${time(item.created)}`));
    const detail = el('details'); detail.append(el('summary', '', '요청·JSON 결과'), el('pre', '', json({arguments: item.args, ...(item.result ? {result: item.result} : {})}))); row.append(detail); return row;
  }));
}
function actionStatus(text, style = '') { $('action-status').textContent = text; $('action-status').className = `action-status ${style}`; $('action-status').hidden = !text; }
function revealTool(name, args) {
  if (args.workspace !== state.workspace) setWorkspace(args.workspace);
  if (args.registration) {
    if (state.selected !== args.registration) { state.selectedStatus = null; state.selectedStatusRevision = null; }
    state.selected = args.registration; document.querySelectorAll('.registration-input').forEach((node) => { node.value = args.registration; });
  }
  if (name === 'research_memory') setView('memory', false);
  else if (['research_help', 'research_export', 'research_restore', 'research_laya_prepare', 'research_laya_resolve'].includes(name)) setView('tools');
  else setView('overview');
  renderWorkflow();
}

/** The only action path for human forms, tool console, and native WebMCP callbacks. */
export async function executeTool(name, parameters = {}, options = {}) {
  const args = {...parameters, workspace: parameters.workspace ?? state.workspace ?? 'default'};
  if (!args.workspace) args.workspace = 'default';
  const source = options.source || '사용자';
  if (options.reveal !== false) revealTool(name, args);
  const call = {tool: name, args, workspace: args.workspace, source, created: new Date().toISOString(), result: null};
  state.calls.unshift(call); state.calls = state.calls.slice(0, 30); state.pending++;
  renderCalls(); actionStatus(`${source} · ${name} 진행 중`, 'busy');
  const envelope = await request('/api/call', {method: 'POST', headers: {'Content-Type': 'application/json', 'X-Research-Session': state.token}, body: json({tool: name, arguments: args})});
  call.result = envelope; state.pending--; renderCalls();
  const toolResult = $('tool-result'); toolResult.replaceChildren(chip(envelope.ok ? 'success' : 'failure'), el('pre', '', json(envelope)));
  if (!envelope.ok) { notify(errorText(envelope), 'error'); actionStatus(errorText(envelope), 'error'); }
  else {
    notify(''); actionStatus(state.pending ? `${state.pending}개 작업 진행 중` : `${name} · 완료`, state.pending ? 'busy' : '');
    const data = envelope.data;
    if (name === 'research_goal' && args.workspace === state.workspace) state.objectiveOffset = Math.floor((currentStatus().goal_total || 0) / PAGE) * PAGE;
    if (name === 'research_memory' && args.workspace === state.workspace) {
      state.memory = data; state.memoryArgs = {query: args.query || '', outcome: args.outcome || null,
        verification: args.verification || null, limit: args.limit ?? PAGE, offset: args.offset ?? 0};
      if (source === 'WebMCP' || options.reveal !== false) { $('memory-query').value = args.query || ''; $('memory-outcome').value = args.outcome || ''; $('memory-verification').value = args.verification || ''; }
      renderMemory();
    }
    const record = data?.record || (data?.registration?.spec && data?.hypothesis ? data : null);
    const registration = record?.registration?.id || (name === 'research_register' ? data?.registration?.id : null) || args.registration;
    if (args.workspace === state.workspace && registration) {
      state.selected = registration;
      if (name === 'research_register' && !data.reused) state.offset = Math.floor((currentStatus().total || 0) / PAGE) * PAGE;
      if (record?.hypothesis) { state.record = record; state.lastDetail = ''; }
      document.querySelectorAll('.registration-input').forEach((node) => { node.value = registration; });
    }
    if (name === 'research_init' || name === 'research_restore') await loadWorkspaces();
  }
  if (args.workspace === state.workspace && name !== 'research_help') await refresh();
  return envelope;
}
async function openEvidence(item) {
  const dialog = $('evidence-dialog'); $('evidence-title').textContent = item.name || labels[item.kind] || '원본 증거';
  $('evidence-meta').textContent = `SHA-256 ${item.sha256 || '—'}`; $('evidence-text').textContent = '원본 증거 조회 중…'; $('evidence-warning').hidden = true;
  if (!dialog.open) dialog.showModal();
  const response = await request(`/api/evidence?${queryString({workspace: state.workspace, registration: state.selected, evidence: item.id})}`);
  if (!response.ok) { $('evidence-text').textContent = errorText(response); return; }
  $('evidence-text').textContent = response.data.text;
  $('evidence-meta').textContent = `SHA-256 ${response.data.evidence?.sha256 || item.sha256} · ${response.data.bytes} bytes`;
  $('evidence-warning').hidden = !response.data.truncated;
  $('evidence-warning').textContent = '큰 원본의 앞부분만 표시했습니다. 원본 파일은 보존되어 있습니다.';
}
function updateToolDescription() {
  const tool = state.tools.find((item) => item.name === $('tool-select').value); if (!tool) return;
  $('tool-description').textContent = tool.description; $('tool-schema').textContent = json(tool.inputSchema);
}
async function registerNativeTools() {
  const badge = $('webmcp-status');
  if (typeof document.modelContext?.registerTool !== 'function') {
    badge.textContent = '이 브라우저에서 WebMCP 미지원'; badge.className = 'badge subtle';
    badge.title = '사람의 웹 조작과 CLI / stdio MCP는 사용할 수 있습니다. 네이티브 WebMCP 지원 브라우저에서는 열린 페이지의 도구를 등록합니다.';
    return;
  }
  let count = 0; const failures = [];
  for (const tool of state.tools) {
    try {
      await document.modelContext.registerTool({name: tool.name, description: tool.description, inputSchema: tool.inputSchema,
        annotations: {readOnlyHint: Boolean(tool.annotations?.readOnlyHint)},
        execute: async (args) => executeTool(tool.name, args || {}, {source: 'WebMCP'})});
      count++;
    } catch (error) { failures.push({name: tool.name, message: error.message}); }
  }
  badge.textContent = `네이티브 WebMCP · ${count}/${state.tools.length}개 도구`;
  badge.className = `badge ${count === state.tools.length ? 'native' : 'warn'}`;
  badge.title = failures.length ? failures.map((item) => `${item.name}: ${item.message}`).join('\n') : '실제 document.modelContext API에 도구를 등록했습니다. 에이전트가 호출하면 해당 연구와 결과가 이 화면에 표시됩니다.';
}
function readForm(form) { return Object.fromEntries(new FormData(form).entries()); }
function bindForm(id, tool, prepare) {
  $(id).addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!state.workspace) { notify('기존 작업공간을 선택하거나 먼저 새 작업공간을 만드세요.'); return; }
    try {
      const values = readForm(event.currentTarget), args = prepare ? prepare(values) : values;
      const submit = event.currentTarget.querySelector('[type="submit"]'); submit.disabled = true;
      try { await executeTool(tool, args); } finally { submit.disabled = false; }
    } catch (error) { notify(`INVALID_INPUT · ${error.message}`, 'error'); }
  });
}
function bindEvents() {
  document.querySelectorAll('[data-view]').forEach((node) => node.addEventListener('click', () => setView(node.dataset.view)));
  document.querySelectorAll('[data-form]').forEach((node) => node.addEventListener('click', () => setForm(node.dataset.form)));
  $('workspace-select').addEventListener('change', async (event) => { setWorkspace(event.target.value); await refresh(); if (state.view === 'memory') searchMemory(0); });
  $('refresh-button').addEventListener('click', async () => {
    // An explicit reconnect obtains the current page session; it never repeats a mutation.
    const bootstrap = await request('/api/bootstrap');
    if (!bootstrap.ok) { notify(errorText(bootstrap), 'error'); return; }
    state.token = bootstrap.data.session_token; $('app-version').textContent = bootstrap.data.version;
    if (!state.tools.length) { state.tools = bootstrap.data.tools; populateTools(); await registerNativeTools(); }
    await loadWorkspaces(!state.workspace); await refresh(); if (state.view === 'memory') searchMemory();
  });
  $('workspaces-prev').addEventListener('click', async () => { state.workspaceOffset = Math.max(0, state.workspaceOffset - PAGE); await loadWorkspaces(); });
  $('workspaces-next').addEventListener('click', async () => { state.workspaceOffset += PAGE; await loadWorkspaces(); });
  $('registrations-prev').addEventListener('click', async () => { state.offset = Math.max(0, state.offset - PAGE); await refresh(); });
  $('registrations-next').addEventListener('click', async () => { state.offset += PAGE; await refresh(); });
  $('objectives-prev').addEventListener('click', async () => { state.objectiveOffset = Math.max(0, state.objectiveOffset - PAGE); await refresh(); });
  $('objectives-next').addEventListener('click', async () => { state.objectiveOffset += PAGE; await refresh(); });
  $('new-registration').addEventListener('click', () => setForm('register')); $('new-goal').addEventListener('click', () => setForm('goal'));
  $('init-form').addEventListener('submit', async (event) => { event.preventDefault(); const name = $('new-workspace').value.trim(); await executeTool('research_init', {workspace: name}); });
  bindForm('goal-form', 'research_goal');
  bindForm('hypothesis-form', 'research_hypothesis', (values) => ({...values, expect: currentStatus().revision}));
  bindForm('register-form', 'research_register', (values) => ({...values, spec: JSON.parse(values.spec), expect: currentStatus().revision}));
  bindForm('evidence-form', 'research_evidence', (values) => ({...values, path: values.path || null, expect: currentStatus().revision}));
  bindForm('decide-form', 'research_decide', (values) => ({...values, expect: currentStatus().revision}));
  $('registration-example').addEventListener('click', async () => {
    const response = await executeTool('research_help', {topic: 'register'}, {reveal: false});
    if (response.ok) { $('register-spec').value = json(response.data.example); const hypotheses = currentStatus().hypotheses || []; if (hypotheses.length === 1) { const spec = response.data.example; spec.hypothesis_id = hypotheses[0].id; $('register-spec').value = json(spec); } }
  });
  $('memory-form').addEventListener('submit', (event) => { event.preventDefault(); searchMemory(0, PAGE); });
  $('memory-prev').addEventListener('click', () => searchMemory(Math.max(0, state.memoryArgs.offset - (state.memory?.limit || PAGE))));
  $('memory-next').addEventListener('click', () => searchMemory(state.memoryArgs.offset + (state.memory?.limit || PAGE)));
  $('tool-select').addEventListener('change', updateToolDescription);
  $('tool-form').addEventListener('submit', async (event) => { event.preventDefault(); try { const args = JSON.parse($('tool-arguments').value); if (!args || Array.isArray(args) || typeof args !== 'object') throw new Error('입력은 JSON 객체여야 합니다.'); await executeTool($('tool-select').value, args); } catch (error) { notify(`INVALID_INPUT · ${error.message}`, 'error'); } });
  $('evidence-close').addEventListener('click', () => $('evidence-dialog').close());
  $('evidence-dialog').addEventListener('click', (event) => { if (event.target === $('evidence-dialog')) { const rect = $('evidence-dialog').getBoundingClientRect(); if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) $('evidence-dialog').close(); } });
}
function populateTools() {
  $('tool-select').replaceChildren(...state.tools.map((tool) => new Option(tool.name, tool.name))); updateToolDescription();
}
async function start() {
  bindEvents(); renderSnapshot(); renderMemory(); renderCalls();
  // Poll reads only. No automatic init, claim, run, verification, or scientific decision.
  setInterval(() => { if (state.token && state.workspace && document.visibilityState !== 'hidden') refresh(); }, 2000);
  document.addEventListener('visibilitychange', () => { if (state.token && document.visibilityState === 'visible') refresh(); });
  const response = await request('/api/bootstrap');
  if (!response.ok) { notify(errorText(response), 'error'); $('webmcp-status').textContent = 'WebMCP 등록 전 · 서버 연결 필요'; return; }
  state.token = response.data.session_token; state.tools = response.data.tools;
  $('app-version').textContent = response.data.version;
  populateTools();
  await loadWorkspaces(true); await refresh(); await registerNativeTools();
}
start();
