"""Research state management, without a model or agent runtime."""
__version__ = "0.2.0"
