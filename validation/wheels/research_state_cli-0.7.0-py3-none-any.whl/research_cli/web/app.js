/* Agent-controlled scenes; deterministic, read-only presentation of the shared store. */
import {buildViewModel, compareRecords, clipText, labelState} from './view_model.js';
const $ = id => document.getElementById(id);
const PAGE = 20, VISIBLE = 3, COMPARE = 6;
const state = {token:null,tools:[],workspace:'',scene:'overview',selected:'',snapshot:null,record:null,summary:null,goal:null,
  limit:PAGE,offset:0,memory:null,overviewMemory:null,memoryArgs:{query:'',outcome:null,verification:null,limit:PAGE,offset:0},
  evidence:null,records:[],compareArgs:null,compareMissing:[],calls:[],pending:0,serial:0,latest:0,refreshing:null,
  connected:false,explanation:'',fingerprints:new Map(),booted:false,refreshScope:'',summarySignature:''};
const scenes = {overview:['연구의 지금','질문, 결과와 남은 불확실성을 함께 봅니다.'],
  analysis:['결과를 읽는 방법','실제 측정값을 사전에 고정한 기준과 비교합니다.'],
  comparison:['시도 사이의 차이','평가 조건이 확인된 시도만 함께 비교합니다.'],
  memory:['이전 시도에서 배운 것','결과와 적용 조건을 함께 읽습니다.'],
  activity:['연구가 움직인 시간','실제 사건의 시각과 순서를 봅니다.'],
  evidence:['근거의 원문','보존된 원문과 현재 해시를 확인합니다.']};
export const presentationTools = [
 {name:'research_view',description:'Control the spectator scenes without human clicks or research mutations. overview is a compact situation summary; analysis shows registered thresholds; comparison groups at most six full records by evaluation conditions; memory searches lessons; activity shows actual events. Every summary returns source references. explanation is an unverified external-agent statement.',
 inputSchema:{type:'object',additionalProperties:false,properties:{
 workspace:{type:'string',description:'Relative workspace; defaults to current display.'},
 scene:{type:'string',enum:['overview','analysis','comparison','memory','activity'],default:'overview'},
 registration:{type:'string',description:'Optional experiment to focus, including an off-page record.'},
 compare:{type:'array',maxItems:6,items:{type:'object',additionalProperties:false,required:['workspace','registration'],properties:{workspace:{type:'string'},registration:{type:'string'}}},description:'comparison only: explicit records beneath the configured root. No scientific ranking.'},
 query:{type:'string',default:''},outcome:{type:['string','null'],enum:[null,'success','failure','inconclusive']},
 verification:{type:['string','null'],enum:[null,'pending','passed','failed','inconclusive']},
 limit:{type:'integer',minimum:1,maximum:100,default:PAGE},offset:{type:'integer',minimum:0,default:0},
 explanation:{type:'string',maxLength:2000,description:'External-agent statement; separate from verified evidence.'}}},
 annotations:{readOnlyHint:true}},
 {name:'research_inspect_evidence',description:'Open one preserved evidence file in a full-width evidence scene. Obtain IDs with research_show. Hash checked through the existing evidence API. Does not execute, verify, adopt, or mutate state. Return via research_view.',
 inputSchema:{type:'object',additionalProperties:false,required:['registration','evidence'],properties:{workspace:{type:'string'},registration:{type:'string'},evidence:{type:'string'},explanation:{type:'string',maxLength:2000}}},
 annotations:{readOnlyHint:true}}
];
function el(tag,className,text){const n=document.createElement(tag);if(className)n.className=className;if(text!==undefined&&text!==null)n.textContent=String(text);return n;}
function svg(tag,attrs={},text){const n=document.createElementNS('http://www.w3.org/2000/svg',tag);Object.entries(attrs).forEach(([k,v])=>n.setAttribute(k,String(v)));if(text!==undefined)n.textContent=text;return n;}
function json(value){return JSON.stringify(value,null,2);}
function finiteJson(value){return JSON.stringify(value,(_k,v)=>{if(typeof v==='number'&&!Number.isFinite(v))throw Error('Input must be finite JSON.');return v;});}
function tone(value){if(['succeeded','passed','adopted','valid','success'].includes(value))return 'good';if(['failed','rejected','tampered','missing','failure'].includes(value))return 'bad';if(['running','unknown','inconclusive'].includes(value))return 'warn';return 'quiet';}
function statePresentation(value,dimension,currentEvidenceUnconfirmed=false){const historical=currentEvidenceUnconfirmed&&((dimension==='verification'&&value==='passed')||(dimension==='decision'&&value==='adopted'));return {text:(historical?'과거 ':'')+labelState(value,dimension),tone:historical?'warn':tone(value)};}
function badge(value,prefix='',dimension,currentEvidenceUnconfirmed=false){const display=statePresentation(value,dimension,currentEvidenceUnconfirmed),node=el('span','state-badge '+display.tone,prefix+display.text);node.dataset.state=value;return node;}
function time(value,seconds=true){const d=new Date(typeof value==='number'?(seconds?value*1000:value):value);return !value||Number.isNaN(d.getTime())?'시각 미확인':new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(d);}
function dateTime(value){const d=new Date(typeof value==='number'?value*1000:value);return Number.isNaN(d.getTime())?'시각 미확인':new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',month:'short',day:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(d);}
function qs(value){return new URLSearchParams(Object.entries(value).filter(([,v])=>v!==undefined&&v!==null)).toString();}
function status(){return state.snapshot?.status||{goals:[],hypotheses:[],registrations:[],revision:null,total:0};}
function envelopeError(code,message,details={}){return {ok:false,error:{code,message,details}};}
function errorText(result){return (result.error?.code||'ERROR')+' · '+(result.error?.message||'조회할 수 없습니다.');}
function notify(text=''){state.noticeKind=text.startsWith('CONNECTION_ERROR')?'connection':'operation';$('notice').textContent=text;$('notice').hidden=!text;}
function animate(node){if(matchMedia('(prefers-reduced-motion: reduce)').matches||typeof node.animate!=='function')return;node.getAnimations().forEach(a=>a.cancel());node.animate([{opacity:.6,transform:'translateY(5px)'},{opacity:1,transform:'translateY(0)'}],{duration:260,easing:'ease-out'});}
function replaceChanged(node,key,children){if(state.fingerprints.get(node.id)===key)return;state.fingerprints.set(node.id,key);node.replaceChildren(...children);animate(node);}
function connection(online){state.connected=online;$('connection-status').textContent=online?'연구 상태 연결':'연결 확인 필요';$('connection-status').dataset.state=online?'connected':'disconnected';}
async function request(path,options={}){try{const res=await fetch(path,{cache:'no-store',credentials:'same-origin',...options}),value=await res.json();if(!value||typeof value.ok!=='boolean')throw Error('Invalid response envelope.');connection(true);return value;}catch(error){connection(false);state.token=null;return envelopeError('CONNECTION_ERROR',error.message);}}
async function ensureSession(){const value=await request('/api/bootstrap');if(value.ok){state.token=value.data.session_token;$('app-version').textContent=value.data.version;}return value;}
async function core(name,args){return request('/api/call',{method:'POST',headers:{'Content-Type':'application/json','X-Research-Session':state.token},body:finiteJson({tool:name,arguments:args})});}
function relativeWorkspace(value){return typeof value==='string'&&value.length>0&&!/^[\\/]|^[A-Za-z]:/.test(value)&&!value.split(/[\\/]/).some(p=>p==='..');}
function workspace(name){if(name===state.workspace)return;state.workspace=name;state.selected='';state.snapshot=null;state.record=null;state.summary=null;state.goal=null;state.evidence=null;state.memory=null;state.overviewMemory=null;state.records=[];state.compareArgs=null;state.compareMissing=[];state.offset=0;state.summarySignature='';state.fingerprints.clear();$('workspace-name').textContent=name||'에이전트 연결 대기';try{localStorage.setItem('research-state-workspace',name);}catch(_){}}
function setScene(scene){state.scene=scene;document.body.dataset.scene=scene;$('scene-title').textContent=scenes[scene][0];$('scene-caption').textContent=state.explanation?'에이전트 설명 · '+clipText(state.explanation,160)+' · 검증 근거와 별개':scenes[scene][1];}
function model(){const memory=state.scene==='overview'?state.overviewMemory:state.memory,vm=buildViewModel({snapshot:state.snapshot,record:state.record,goal:state.goal,summary:state.summary,memory,records:state.records,limit:state.limit,offset:state.offset,workspace:state.workspace});if(state.scene==='overview'&&memory)vm.refs=vm.refs.filter(ref=>ref.field!=='memory').concat(memory.queries.map(query=>({field:'memory',...query.arguments,revision:query.revision})));return vm;}
export function getViewState(){return {workspace:state.workspace,scene:state.scene,selectedRegistration:state.selected,revision:status().revision,limit:state.limit,offset:state.offset,pendingCalls:state.pending,connected:state.connected,humanControls:false,memory:{...state.memoryArgs},overviewMemory:state.overviewMemory?{selection:state.overviewMemory.selection,queries:state.overviewMemory.queries}:null,evidence:state.evidence?.evidence?.id||null,visibleLimit:VISIBLE,comparison:state.records.map(r=>({workspace:r.workspace||state.workspace,registration:r.registration.id})),sourceReferences:model().refs};}
function card(kicker,title,classes=''){const n=el('section','card '+classes),head=el('header','card-heading');head.append(el('span','card-kicker',kicker),el('h2','card-title',title));n.append(head);return n;}
function note(text){return el('p','card-note',text);}
function conditions(items,limit=8){const n=el('dl','condition-list');items.slice(0,limit).forEach(item=>{const row=el('div');row.append(el('dt','',item.label),el('dd','',typeof item.value==='string'?item.value:json(item.value)));n.append(row);});if(items.length>limit)n.append(note('표시 '+limit+' / '+items.length+'개 조건 · 원본은 에이전트가 조회합니다.'));return n;}
function rail(vm){const node=el('div','state-rail');const values=[state.record||status().goal_total?'recorded':'pending',state.record||status().hypothesis_total?'proposed':'pending',state.record?'registered':'pending',vm.states.execution,vm.states.verification,vm.states.decision];['목표','가설','사전등록','실행','검증','결정'].forEach((name,i)=>{const step=el('div','state-step'),dimension=i===3?'execution':i===4?'verification':i===5?'decision':undefined,display=statePresentation(values[i],dimension,vm.trust.invalidCount>0);step.dataset.stage=i;step.dataset.tone=display.tone;step.dataset.state=values[i];step.append(el('span','stage-label',name),el('strong','stage-value',display.text));node.append(step);});node.setAttribute('aria-label','선택한 연구의 연결 · 실행, 검증과 결정은 별개');return node;}
function metricPlot(metric){
 const box=el('div','metric-row'),head=el('div','metric-heading');
 head.append(el('strong','',metric.name),el('span','metric-unit',metric.unit));box.append(head);
 const resultTone=!metric.supported?'quiet':metric.criteria.some(c=>c.passed===false)?'bad':'good';
 box.append(el('div','metric-number '+(!metric.supported?'muted':resultTone),metric.value===null?'미측정':String(metric.value)));
 const numeric=metric.criteria.filter(c=>typeof c.threshold==='number'&&Number.isFinite(c.threshold));
 if(metric.value===null&&!numeric.length){box.append(note('측정값과 등록 기준이 아직 없습니다.'));return box;}
 const domain=metric.domain||[0,1],min=domain[0],max=domain[1],scale=Math.max(Math.abs(min),Math.abs(max),1),range=max/scale-min/scale||1,x=v=>42+Math.max(0,Math.min(1,(v/scale-min/scale)/range))*476;
 const drawing=svg('svg',{viewBox:'0 0 560 96',role:'img','aria-label':metric.name+' 실측 '+(metric.value??'없음')+' · 기준 '+metric.criteria.map(c=>c.op+' '+c.threshold).join(', ')+' · '+metric.unit});
 numeric.forEach(c=>{if(['>=','>','<=','<'].includes(c.op)){const a=['>=','>'].includes(c.op)?x(c.threshold):42,b=['>=','>'].includes(c.op)?518:x(c.threshold);drawing.append(svg('rect',{x:a,y:26,width:Math.max(0,b-a),height:18,class:'plot-region'}));}});
 drawing.append(svg('line',{x1:42,x2:518,y1:36,y2:36,class:'plot-axis'}));
 [min,min/2+max/2,max].forEach(v=>drawing.append(svg('line',{x1:x(v),x2:x(v),y1:47,y2:53,class:'plot-tick'}),svg('text',{x:x(v),y:73,'text-anchor':'middle',class:'plot-label'},Number(v.toPrecision(4)))));
 numeric.forEach(c=>drawing.append(svg('line',{x1:x(c.threshold),x2:x(c.threshold),y1:17,y2:53,class:'plot-threshold'})));
 if(metric.value!==null)drawing.append(svg('circle',{cx:x(metric.value),cy:36,r:7,class:'plot-measure '+(metric.supported?'':'historical'),'data-tone':resultTone}));
 box.append(drawing);const legend=el('div','metric-legend');
 legend.append(el('span',metric.supported?'measure-key':'historical-key',metric.value===null?'측정값 없음':metric.supported?'● 독립 측정':'○ 과거 수치 · 현재 확인 안 됨'),el('span','threshold-key','│ 사전등록 기준'));
 box.append(legend);
 metric.criteria.forEach(c=>box.append(note('기준 '+c.op+' '+c.threshold+' · '+(c.passed===true?'충족':c.passed===false?'미충족':'현재 판정 미확인'))));
 if(!metric.criteria.length)box.append(note('등록 기준 없음 · 숫자만으로 성공을 판단하지 않습니다.'));
 return box;
}
function distribution(vm){const box=el('div','distribution'),parts=[['실행',vm.distribution.execution],['검증 기록',vm.distribution.verification],['결정',vm.distribution.decision]];parts.forEach(([label,items])=>{const row=el('div','distribution-row'),track=el('div','distribution-track'),legend=el('div','distribution-legend');row.append(el('strong','',label));const nonzero=items.filter(i=>i.count);if(!nonzero.length)legend.append(el('span','','기록 없음'));nonzero.forEach(item=>{legend.append(el('span','',item.label+' '+item.count));const s=el('span','distribution-segment '+tone(item.key));s.style.flexGrow=item.count;s.setAttribute('aria-label',item.label+' '+item.count+'건');track.append(s);});row.append(legend,track);box.append(row);});box.append(note(vm.scope.label));return box;}
function timelinePlot(timeline){const items=timeline.items.filter(i=>Number.isFinite(i.created));if(!items.length)return note('시각이 기록된 사건이 없습니다.');const min=Math.min(...items.map(i=>i.created)),max=Math.max(...items.map(i=>i.created)),range=max-min||1,drawing=svg('svg',{viewBox:'0 0 720 146',role:'img','aria-label':'실제 사건 시간축 '+dateTime(min)+'부터 '+dateTime(max)+'까지, '+items.length+'개 사건'});drawing.append(svg('line',{x1:36,x2:684,y1:66,y2:66,class:'plot-axis'}));items.forEach((item,i)=>{const x=36+(item.created-min)/range*648,y=i%2===0?38:92;drawing.append(svg('line',{x1:x,x2:x,y1:66,y2:y,class:'plot-tick'}),svg('circle',{cx:x,cy:66,r:4,class:'plot-measure'}),svg('text',{x:x,y:y+(i%2===0?-5:15),'text-anchor':'middle',class:'plot-label'},i+1));});drawing.append(svg('text',{x:36,y:138,class:'plot-label'},time(min)),svg('text',{x:684,y:138,'text-anchor':'end',class:'plot-label'},time(max)));const box=el('div','timeline-chart');box.append(drawing,note(timeline.label+' · 점 사이 간격은 실제 시간, 번호는 아래 사건 순서'));return box;}
function question(vm){const nodes=[el('span','card-kicker','함께 보고 있는 연구'),el('h2','question-title clamp-2',vm.question.title),el('p','question-hypothesis clamp-2',vm.question.hypothesis||'가설 기록 대기'),el('p','study-scope clamp-2',vm.question.scope||'현재 등록의 적용 범위를 확인하세요.')];replaceChanged($('research-context'),json(vm.question),nodes);const names=Object.keys(scenes);replaceChanged($('scene-index'),state.scene,names.map(s=>{const n=el('span',state.scene===s?'scene-current':'',scenes[s][0]);n.setAttribute('aria-current',state.scene===s?'page':'false');return n;}));$('revision-label').textContent='기록 버전 '+(status().revision??'미확인');}
function overview(vm){
 const fragment=el('div');fragment.append(rail(vm));
 const grid=el('div','overview-grid'),results=card('이번 시도의 결과',vm.question.change||'아직 실행할 실험이 없습니다.','result-card');
 vm.metrics.slice(0,1).forEach(m=>results.append(metricPlot(m)));if(!vm.metrics.length)results.append(note('독립 검증의 측정값이 아직 없습니다. 실행 성공과 검증 성공은 별도로 기록됩니다.'));
 if(vm.metrics.length>1)results.append(note('등록 지표 '+vm.metrics.length+'개 · 전체는 결과 분석 장면에서 봅니다.'));
 const trust=card('확인된 것과 남은 것',vm.stage.text,'trust-card');
 const badges=el('div','badge-row'),currentEvidenceUnconfirmed=vm.trust.invalidCount>0;badges.append(badge(vm.states.execution,'','execution'),badge(vm.states.verification,'','verification',currentEvidenceUnconfirmed),badge(vm.states.decision,'','decision',currentEvidenceUnconfirmed));trust.append(badges);
 const current=el('p','trust-message '+vm.trust.tone,vm.trust.text);trust.append(current, note('원본 보존 · '+vm.trust.validCount+' / '+vm.trust.total+'개 해시 일치 · 과학적 검증과 별개'));
 const blockers=el('ul','blocker-list');vm.blockers.slice(0,2).forEach(b=>blockers.append(el('li','',b.text)));if(!vm.blockers.length)blockers.append(el('li','',state.record?'현재 상태 규칙상 추가로 요구되는 증거 없음':'실험을 사전등록하면 필요한 증거를 표시합니다.'));trust.append(blockers);
 const pending=vm.resources.filter(r=>!r.known).length;if(pending)trust.append(note('미확인 자원 기록 '+pending+'개 · 분석 장면에서 확인'));
 grid.append(results,trust);fragment.append(grid);
 const insights=el('div','insight-grid'),attempts=card('조회한 시도','시도의 상태');attempts.append(distribution(vm));
 const recent=card('최근 연구 사건','무엇이 달라졌는가');vm.timeline.items.slice(-2).forEach(e=>{const row=el('div','mini-event');row.append(el('time','',time(e.created)),el('strong','',e.title));recent.append(row);});recent.append(note(vm.timeline.label));
 const learning=card('기억과 적용 범위','축적한 교훈'),previous=vm.lessons.filter(lesson=>lesson.ref?.registration!==state.selected);
 const lesson=['failure','success','inconclusive'].map(outcome=>previous.find(item=>item.outcome===outcome)).find(Boolean);
 if(lesson){const original=state.overviewMemory?.items.find(item=>item.id===lesson.ref?.registration),reason=typeof original?.reason==='string'?clipText(original.reason,220):'';learning.append(el('p','clamp-2',reason?'결정 이유 · '+reason:'기록된 가설 · '+lesson.summary),note(lesson.claimText));}
 else learning.append(note(vm.lessons.some(item=>item.ref?.registration===state.selected)?'결과별 최근 조회에 다른 시도의 기억 없음 · 이번 결과는 저장되어 있습니다.':'조회한 연구 기억이 없습니다.'));
 if(state.overviewMemory?.queries.some(query=>!query.ok))learning.append(note('일부 결과별 기억을 조회하지 못했습니다.'));
 learning.append(note('결과별 최근 기억 · 조건은 기억 장면에서'));insights.append(attempts,recent,learning);fragment.append(insights);return fragment;
}
function analysis(vm){const wrap=el('div','analysis-grid'),result=card('사전등록 대비 실측','등록 기준은 실행 전에 고정됩니다');vm.metrics.slice(0,6).forEach(m=>result.append(metricPlot(m)));if(!vm.metrics.length)result.append(note('측정값이 없습니다.'));if(vm.metrics.length>6)result.append(note('표시 6 / '+vm.metrics.length+'개 지표 · 원본은 research_show'));result.append(note(vm.trust.text));const context=card('적용 조건','어디까지 이 결과를 사용할 수 있는가');context.append(conditions(vm.conditions),el('h3','','결정 이유'),el('p','clamp-3',clipText(state.record?.decision?.reason||'결정 기록 대기',450)),el('h3','','자원 기록'));context.append(conditions(vm.resources.map(r=>({label:r.label,value:r.known?r.value:'미확인'})),6),note('실행 경과 시간은 외부 에이전트의 총 연구 시간이나 토큰 사용량과 다릅니다.'));wrap.append(result,context);return wrap;}
function comparison(vm){
 const wrap=el('div'),groups=compareRecords(state.records);
 wrap.append(note('비교 원본 '+state.records.length+'건 · 최대 '+COMPARE+'건 · 순위와 종합 점수를 만들지 않습니다.'));
 if(state.compareMissing.length)wrap.append(note('조회할 수 없는 비교 기록 '+state.compareMissing.length+'건 · 원본 확인 필요'));
 if(!groups.length){wrap.append(el('div','empty-scene','비교할 원본 기록이 없습니다. 에이전트가 비교할 실험을 지정하세요.'));return wrap;}
 groups.forEach((g,index)=>{
  const group=card('평가 조건 그룹 '+(index+1),g.comparable?'평가 조건이 같은 시도':'함께 순위를 매길 수 없는 기록');
  group.append(note(g.reason));
  const context=conditions((g.conditions||[]).filter(c=>['비교 기준','데이터 분할','Seed'].includes(c.label)).map(c=>({...c,value:clipText(c.value,180)})),3);
  context.setAttribute('aria-label','이 묶음의 비교 기준, 데이터 분할과 Seed 요약');
  context.querySelectorAll('dd').forEach(value=>value.classList.add('clamp-2'));
  group.append(context,note('등록 조건 요약 · 전체는 연결된 원본 등록에서 확인합니다.'));
  const sharedDomains=new Map();
  if(g.comparable)g.items.flatMap(item=>item.metrics).forEach(m=>{const d=sharedDomains.get(m.name)||m.domain;sharedDomains.set(m.name,[Math.min(d[0],m.domain[0]),Math.max(d[1],m.domain[1])]);});
  if(g.differences?.length)group.append(note('시도 차이 · '+g.differences.map(d=>typeof d==='string'?d:json(d)).join(' · ')));
  const grid=el('div','comparison-grid');
  g.items.forEach(item=>{
   const attempt=el('article','attempt-card');
   attempt.append(el('h3','clamp-2',item.title),note(typeof item.source==='string'?item.source:'소스 버전은 원본에 고정됨'));
   const statuses=el('div','badge-row'),currentEvidenceUnconfirmed=!item.metrics.length||item.metrics.some(metric=>!metric.supported);
   statuses.append(badge(item.states.execution,'','execution'),badge(item.states.verification,'','verification',currentEvidenceUnconfirmed),badge(item.states.decision,'','decision',currentEvidenceUnconfirmed));
   attempt.append(statuses);
   item.metrics.slice(0,2).forEach(m=>attempt.append(metricPlot(sharedDomains.has(m.name)?{...m,domain:sharedDomains.get(m.name)}:m)));
   if(!item.metrics.length)attempt.append(note('측정값 미확인'));
   grid.append(attempt);
  });
  group.append(grid);wrap.append(group);
 });
 return wrap;
}
function memory(vm){const wrap=el('div'),data=state.memory,args=state.memoryArgs;wrap.append(note('에이전트 검색 “'+(args.query||'전체')+'” · '+(args.outcome?labelState(args.outcome):'모든 결과')+' · 조회 '+(data?.items?.length||0)+' / 검색 결과 '+(data?.total||0)+'건'));const grid=el('div','memory-grid');vm.lessons.slice(0,VISIBLE).forEach(item=>{const n=card(labelState(item.outcome),'조건과 함께 읽는 교훈','attempt-card');n.append(el('h3','clamp-2',clipText(item.title,180)),el('p','clamp-3',clipText(item.summary,280)),el('p','clamp-3',clipText(item.reason||'결정 이유 기록 없음',280)),note(item.claimText),conditions(item.conditions||[],3));grid.append(n);});if(!vm.lessons.length)grid.append(el('div','empty-scene','조건에 맞는 기억이 없습니다. 빈 검색 결과는 가설의 성공·실패 증거가 아닙니다.'));wrap.append(grid,note('화면 표시 '+Math.min(VISIBLE,vm.lessons.length)+' / 이번 조회 '+vm.lessons.length+'건 · 에이전트가 limit/offset으로 다른 페이지를 펼칩니다.'));return wrap;}
function activity(vm){const wrap=el('div','analysis-grid'),events=card('실제 연구 사건','시간에 따른 상태와 근거의 도착');const visibleTimeline={...vm.timeline,items:vm.timeline.items.slice(-6),label:'시간축 표시 '+Math.min(6,vm.timeline.items.length)+'개 · '+vm.timeline.label};events.append(timelinePlot(visibleTimeline));const list=el('ol','timeline-list');vm.timeline.items.slice(-6).forEach((item,i)=>{const n=el('li','mini-event');n.append(el('time','',dateTime(item.created)),el('strong','',(i+1)+'. '+item.title));list.append(n);});events.append(list,note('목록은 최근 '+Math.min(6,vm.timeline.items.length)+'개 · 전체 시간축은 이번 조회 범위'));const calls=card('외부 에이전트 활동','이 페이지에서 요청한 내용');state.calls.slice(0,4).forEach(c=>{const n=el('div','mini-event');n.append(el('time','',time(c.created)),el('strong','',c.tool),note(c.result?(c.result.ok?'요청 완료':errorText(c.result)):'요청 처리 중'));calls.append(n);});if(!state.calls.length)calls.append(note('이 페이지의 도구 호출 없음'));calls.append(note('도구 요청 완료는 전체 연구 완료를 뜻하지 않습니다. 이 목록은 영속 연구 사건과 별개입니다.'));wrap.append(events,calls);return wrap;}
function evidence(vm){const wrap=el('div','evidence-layout'),meta=card('원본으로 추적',state.evidence?.evidence?.name||'원본 확인 필요','evidence-meta'),data=state.evidence;if(data){meta.append(conditions([{label:'종류',value:labelState(data.evidence.kind)},{label:'파일 보존',value:'현재 해시 일치'},{label:'등록 연결',value:data.evidence.registration_id},{label:'증거 식별자',value:data.evidence.id},{label:'보존 경로',value:data.evidence.path},{label:'SHA-256',value:data.evidence.sha256},{label:'파일 크기',value:data.bytes+' bytes'}]));}else meta.append(note('원문이 없거나 현재 무결성을 확인할 수 없습니다. 에이전트가 증거를 다시 지정해야 합니다.'));meta.append(note('해시 일치는 파일 보존 상태입니다. 이 원문의 내용에 대한 과학적 타당성을 증명하지 않습니다.'),note(vm.trust.text));const original=card('보존된 내용',data?.truncated?'원문 앞부분 · 최대 256 KiB':'에이전트가 선택한 원문');const pre=el('pre','evidence-text',data?.text||'표시할 수 있는 원문 없음');pre.setAttribute('aria-label','보존된 원본 증거 내용');original.append(pre);if(data?.truncated)original.append(note('화면 표시가 잘렸습니다. 전체 보존 원본은 유지됩니다.'));wrap.append(meta,original);return wrap;}
function render(){const vm=model();question(vm);setScene(state.scene);const draw={overview,analysis,comparison,memory,activity,evidence}[state.scene];const key=json({scene:state.scene,vm,evidence:state.scene==='evidence'?state.evidence:null,records:state.scene==='comparison'?state.records:null,calls:state.scene==='activity'?state.calls:null});replaceChanged($('scene-content'),key,[draw(vm)]);pulseGraph();}
function drawOverview(){render();} function drawMemory(){render();} function drawEvidence(){render();} function drawFocus(){render();} function drawCalls(){if(state.scene==='activity')render();} function drawGraph(){render();}
function pulseGraph(){const call=state.calls.find(c=>!c.result),map={research_goal:0,research_hypothesis:1,research_register:2,research_run:3,research_recover:3,research_verify:4,research_decide:5};document.querySelectorAll('.state-step').forEach(n=>n.classList.toggle('agent-focus',Number(n.dataset.stage)===map[call?.tool]));}
function agentPhase(call,phase){document.body.dataset.phase=phase;$('agent-phase').textContent=phase==='running'?'요청 처리 중':phase==='error'?'요청 거부':phase==='succeeded'?'요청 완료':'에이전트 관전';$('agent-tool').textContent=call?.tool||'WebMCP로 장면과 초점을 변경합니다';$('agent-description').textContent=phase==='running'?'실제 응답 대기':phase==='error'?'오류 원인을 확인하세요':'사용자는 보고 싶은 내용을 에이전트에게 요청하세요';$('agent-status').textContent=phase==='running'?state.pending+'개 요청 처리 중':phase==='error'?errorText(call.result):'도구 완료와 전체 연구 완료는 별개';$('action-status').hidden=phase!=='error';$('action-status').textContent=phase==='error'?errorText(call.result):'';pulseGraph();}
async function readComparison(){const name=state.workspace,selected=state.selected,explicit=state.compareArgs;const refs=explicit||[...new Set([selected,...status().registrations.map(r=>r.id)].filter(Boolean))].slice(0,COMPARE).map(registration=>({workspace:name,registration}));const results=await Promise.all(refs.map(async ref=>({ref,value:await core('research_show',ref)})));if(name!==state.workspace||selected!==state.selected||explicit!==state.compareArgs)return;state.records=results.filter(r=>r.value.ok).map(r=>({...r.value.data,workspace:r.ref.workspace}));state.compareMissing=results.filter(r=>!r.value.ok).map(r=>({ref:r.ref,error:r.value.error}));}
async function lookupSummary() {
  if (!state.record) return;
  const signature = json([state.workspace, state.selected, status().revision, state.record.evidence.map((item) => [item.id, item.integrity])]);
  const visible = status().registrations.find((item) => item.id === state.selected); if (visible) state.summary = visible;
  const goalId = state.record.registration.goal_id; state.goal = status().goals.find((item) => item.id === goalId) || (state.goal?.id === goalId ? state.goal : null);
  if (visible && state.goal) return;
  if (state.summary && state.summarySignature === signature) return;
  const name = state.workspace, id = state.selected;
  for (let offset = 0; ; offset += 100) {
    const response = await core('research_status', {workspace: name, goal: goalId, limit: 100, offset});
    if (state.workspace !== name || state.selected !== id || !response.ok) return;
    state.goal = response.data.goals.find((item) => item.id === goalId) || state.goal;
    const row = response.data.registrations.find((item) => item.id === id); if (row) { state.summary = row; state.summarySignature = signature; return; }
    if (offset + 100 >= response.data.total) return;
  }
}
async function readSelection() {
  if (!state.selected) return {ok: true}; const name = state.workspace, id = state.selected;
  const result = await core('research_show', {workspace: name, registration: id}); if (name !== state.workspace || id !== state.selected) return result;
  if (result.ok) { state.record = result.data; await lookupSummary(); } else { state.record = null; state.summary = null; notify(errorText(result)); } return result;
}
async function readOverviewMemory(name) {
  const outcomes=['failure','success','inconclusive'];
  const replies=await Promise.all(outcomes.map(async outcome=>{const args={workspace:name,query:'',outcome,limit:1,offset:0};return {arguments:args,result:await core('research_memory',args)};}));
  if(name!==state.workspace)return;
  const successful=replies.filter(reply=>reply.result.ok),revisions=successful.map(reply=>reply.result.data.revision);
  const items=successful.flatMap(reply=>reply.result.data.items.slice(0,1));
  state.overviewMemory={items,total:successful.length===outcomes.length?successful.reduce((count,reply)=>count+reply.result.data.total,0):null,limit:VISIBLE,offset:0,
    revision:revisions.find(revision=>revision!==status().revision)??revisions[0]??null,
    selection:{method:'latest_per_outcome',outcomes,perOutcomeLimit:1,offset:0,insightPriority:outcomes,insightExcludeRegistration:state.selected,mixedRevisions:new Set(revisions).size>1},
    queries:replies.map(reply=>({arguments:reply.arguments,ok:reply.result.ok,total:reply.result.data?.total??null,revision:reply.result.data?.revision??null,
      registration:reply.result.data?.items?.[0]?.id||null,...(!reply.result.ok?{error:reply.result.error}:{} )}))};
}
export async function refresh() {
  const scope = json([state.workspace, state.limit, state.offset, state.selected]);
  if (state.refreshing) {
    if (state.refreshScope === scope) return state.refreshing;
    await state.refreshing;
    return refresh();
  }
  if (!state.workspace) { drawOverview(); return {ok: true}; }
  const name = state.workspace, limit = state.limit, offset = state.offset;
  state.refreshScope = scope;
  state.refreshing = (async () => {
    if (!state.token) { const boot = await ensureSession(); if (!boot.ok) return boot; }
    const result = await request(`/api/snapshot?${qs({workspace: name, limit, offset, registration: state.selected || undefined})}`);
    if (name !== state.workspace || limit !== state.limit || offset !== state.offset) return result;
    if (!result.ok) { notify(errorText(result)); return result; }
    if(state.noticeKind==='connection')notify();
    state.snapshot = result.data;
    if (!state.selected && result.data.status.registrations.length) state.selected = result.data.status.registrations[0].id;
    await readSelection();
    // Files can change without a SQLite revision; displayed claims must recheck current integrity.
    if (state.scene === 'overview') await readOverviewMemory(name);
    if (state.scene === 'memory') {
      const memory = await core('research_memory', {...state.memoryArgs, workspace: name});
      if (name === state.workspace) state.memory = memory.ok ? memory.data : null;
    }
    if (state.scene === 'comparison') await readComparison();
    if (state.scene === 'evidence' && state.evidence) {
      const evidence = await request(`/api/evidence?${qs({workspace: name, registration: state.selected, evidence: state.evidence.evidence.id})}`);
      if (name === state.workspace && evidence.ok) state.evidence = evidence.data;
      else if (name === state.workspace && !evidence.ok) { state.evidence = null; notify(errorText(evidence)); }
    }
    $('updated-label').textContent = `${time(Date.now() / 1000)} 조회 · 읽기 상태 동기화`;
    drawOverview(); if (state.scene === 'memory') drawMemory(); if (state.scene === 'evidence') drawEvidence(); return result;
  })();
  try { return await state.refreshing; } finally { state.refreshing = null; }
}
function validatePresentation(name, args) {
  const tool = presentationTools.find((item) => item.name === name), properties = tool.inputSchema.properties;
  for (const key of Object.keys(args)) if (!(key in properties)) throw new Error(`Unknown field: ${key}`);
  for (const key of tool.inputSchema.required || []) if (typeof args[key] !== 'string' || !args[key]) throw new Error(`Required text: ${key}`);
  for (const [key, value] of Object.entries(args)) {
    const schema = properties[key], types = Array.isArray(schema.type) ? schema.type : [schema.type];
    if (!types.some((type) => type === 'null' ? value === null : type === 'integer' ? Number.isInteger(value) : type === 'array' ? Array.isArray(value) : typeof value === type)) throw new Error(`Invalid type: ${key}`);
    if (schema.enum && !schema.enum.includes(value)) throw new Error(`Invalid value: ${key}`);
    if (schema.minimum !== undefined && value < schema.minimum || schema.maximum !== undefined && value > schema.maximum) throw new Error(`Out of range: ${key}`);
    if (schema.maxLength && value.length > schema.maxLength) throw new Error(`Too long: ${key}`);
    if (schema.maxItems && value.length > schema.maxItems) throw new Error(`Too many records: ${key}`);
    if (key === 'compare') {
      if (args.scene !== 'comparison') throw new Error('compare requires the comparison scene.');
      for (const item of value) if (!item || typeof item !== 'object' || Array.isArray(item) ||
        Object.keys(item).some(field => !['workspace', 'registration'].includes(field)) ||
        !relativeWorkspace(item.workspace) || typeof item.registration !== 'string' || !item.registration) throw new Error('Invalid comparison record.');
    }
  }
}
async function present(name, args) {
  if (name === 'research_view') {
    state.limit = args.limit ?? PAGE; state.offset = args.offset ?? 0;
    if (args.scene === 'comparison') { state.compareArgs = args.compare || null; state.records = []; state.compareMissing = []; }
    if (args.registration && args.registration !== state.selected) { state.selected = args.registration; state.record = null; state.summary = null; }
    setScene(args.scene || 'overview'); const snapshot = await refresh(); if (!snapshot?.ok) return snapshot;
    if (args.registration && !state.record) return envelopeError('NOT_FOUND', 'Selected registration could not be displayed.');
    if (state.scene === 'memory') {
      state.memoryArgs = {query: args.query ?? '', outcome: args.outcome ?? null, verification: args.verification ?? null, limit: state.limit, offset: state.offset};
      const result = await core('research_memory', {...state.memoryArgs, workspace: state.workspace}); if (!result.ok) return result;
      state.memory = result.data; drawMemory(); return {ok: true, data: {presentation: getViewState(), memory: result.data}};
    }
    return {ok: true, data: {presentation: getViewState(), viewModel: model(), comparisons: state.scene === 'comparison' ? compareRecords(state.records) : undefined, status: status(), events: state.scene === 'activity' ? state.snapshot.events : undefined}};
  }
  state.selected = args.registration; const selected = await readSelection(); if (!selected.ok) return selected;
  state.evidence = null; setScene('evidence');
  const result = await request(`/api/evidence?${qs({workspace: state.workspace, registration: args.registration, evidence: args.evidence})}`);
  if (!result.ok) { render(); return result; }
  state.evidence = result.data; render(); return {ok: true, data: {...result.data, presentation: getViewState(), sourceReferences: model().refs}};
}
/** Native WebMCP is the action entry point. Background refresh only reads. */
export async function executeTool(name, parameters = {}) {
  if (!parameters || typeof parameters !== 'object' || Array.isArray(parameters)) return envelopeError('INVALID_INPUT', 'Arguments must be a JSON object.');
  const isPresentation = presentationTools.some((item) => item.name === name);
  if (!isPresentation && !state.tools.some((item) => item.name === name)) return envelopeError('INVALID_INPUT', 'Unknown page tool.');
  const args = {...parameters, workspace: parameters.workspace ?? (isPresentation ? state.workspace || 'default' : 'default')};
  try { finiteJson(args); if (!relativeWorkspace(args.workspace)) throw new Error('Workspace must be a relative name within the fixed root.'); if (isPresentation) validatePresentation(name, args); }
  catch (error) { return envelopeError('INVALID_INPUT', error.message); }
  const boot = await ensureSession(); if (!boot.ok) return boot;
  const call = {id: ++state.serial, tool: name, workspace: args.workspace, created: new Date().toISOString(), result: null};
  state.latest = call.id; state.calls.unshift(call); state.calls = state.calls.slice(0, 30); state.pending++;
  workspace(args.workspace); state.explanation = isPresentation ? args.explanation || '' : '';
  if (!isPresentation) setScene(name === 'research_memory' ? 'memory' : ['research_help', 'research_export', 'research_restore', 'research_laya_prepare', 'research_laya_resolve'].includes(name) ? 'activity' : 'overview');
  if (args.registration && state.selected !== args.registration) { state.selected = args.registration; state.record = null; state.summary = null; }
  notify(); drawOverview(); drawCalls(); agentPhase(call, 'running'); let result;
  try {
    result = isPresentation ? await present(name, args) : await core(name, args);
    if (result.ok && state.latest === call.id && state.workspace === args.workspace && !isPresentation) {
      const data = result.data;
      if (name === 'research_status') { state.limit = args.limit ?? PAGE; state.offset = args.offset ?? 0; }
      if (name === 'research_memory') { state.memory = data; state.memoryArgs = {query: args.query || '', outcome: args.outcome || null, verification: args.verification || null, limit: args.limit ?? PAGE, offset: args.offset ?? 0}; drawMemory(); }
      const record = data?.registration?.spec && data?.hypothesis ? data : null;
      const registration = record?.registration?.id || data?.record?.registration?.id || (name === 'research_register' ? data?.registration?.id : null) || args.registration;
      if (registration) { state.selected = registration; state.record = record; state.summary = null; }
      if (name === 'research_register' && !data.reused) state.offset = Math.floor((status().total || 0) / state.limit) * state.limit;
      if (name !== 'research_help') await refresh();
    }
  } catch (error) { result = envelopeError('CLIENT_ERROR', error.message); }
  call.result = result; state.pending--;
  if (result.ok && result.data?.presentation) result.data.presentation = getViewState();
  drawCalls();
  if (state.latest === call.id) { if (!result.ok) notify(errorText(result)); agentPhase(call, result.ok ? 'succeeded' : 'error'); } return result;
}
async function registerNativeTools() {
  const list = [...state.tools, ...presentationTools], node = $('webmcp-status');
  if (typeof document.modelContext?.registerTool !== 'function') { node.textContent = 'WebMCP 미지원 · 관전만 가능'; notify('이 브라우저에서는 에이전트의 웹 제어를 사용할 수 없습니다. 네이티브 WebMCP 지원 브라우저에서 이 페이지를 여세요. CLI 상태 변화는 계속 관전합니다.'); return; }
  let count = 0; const failures = [];
  for (const tool of list) { try { await document.modelContext.registerTool({name: tool.name, description: tool.description, inputSchema: tool.inputSchema, annotations: {readOnlyHint: Boolean(tool.annotations?.readOnlyHint)}, execute: async (args) => executeTool(tool.name, args || {})}); count++; } catch (error) { failures.push(`${tool.name}: ${error.message}`); } }
  node.textContent = `NATIVE WebMCP · ${count}/${list.length}`; node.dataset.state = count === list.length ? 'connected' : 'partial'; if (failures.length) notify(failures.join(' · '));
}
async function autoSelectWorkspace() {
  const result = await request(`/api/workspaces?${qs({limit: PAGE, offset: 0})}`); if (!result.ok) return;
  let saved = ''; try { saved = localStorage.getItem('research-state-workspace') || ''; } catch (_) { /* Optional only. */ }
  const items = result.data.items || [], preferred = items.find((item) => item.name === saved) || [...items].sort((a, b) => b.revision - a.revision)[0]; if (preferred) workspace(preferred.name);
}
async function start() {
  document.body.dataset.phase = 'idle'; setScene('overview'); agentPhase(null, 'idle'); drawOverview(); drawMemory(); drawCalls();
  const result = await ensureSession();
  if (result.ok) { state.tools = result.data.tools; await autoSelectWorkspace(); await refresh(); await registerNativeTools(); state.booted = true; }
  else { notify(errorText(result)); $('webmcp-status').textContent = 'WebMCP · 서버 연결 대기'; }
  // No automatic init, run, recovery mutation, verification, scientific choice, or model call.
  setInterval(async () => {
    if (document.visibilityState === 'hidden') return;
    if (!state.booted) { const boot = await ensureSession(); if (!boot.ok) return; state.tools = boot.data.tools; await autoSelectWorkspace(); await registerNativeTools(); state.booted = true; }
    if (!state.workspace) await autoSelectWorkspace(); await refresh();
  }, 2000);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') refresh(); });
  window.addEventListener('resize', drawGraph);
}
start();
