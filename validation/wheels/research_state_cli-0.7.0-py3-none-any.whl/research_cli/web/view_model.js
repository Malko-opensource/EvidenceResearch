/* Read-only presentation of durable research facts. No state transitions or judgments. */
const LABELS = Object.freeze({registered: '조건 고정', running: '실행 중', succeeded: '실행 성공',
  failed: '실패', unknown: '실행 미확정', pending: '대기', passed: '검증 통과', adopted: '채택',
  rejected: '기각', inconclusive: '미결', valid: '해시 일치', tampered: '변조 감지', missing: '파일 누락',
  no_file: '원본 파일 없는 주장', measured: '측정값', literature: '문헌 주장', inference: '추론',
  proposal: '미실행 제안', success: '성공', failure: '실패', unrecorded: '아직 기록 없음',
  recorded: '목표 기록', proposed: '가설 제안'});
const EVENT_LABELS = Object.freeze({'goal.create': '연구 목표 기록', 'hypothesis.create': '가설 제안',
  'validator.register': '독립 검증기 고정', 'registration.create': '실험 조건 사전등록',
  'run.claim': '실행 요청 확보', 'run.complete': '실행 증거 수집', 'run.unknown': '실행 여부 미확정',
  'verification.complete': '독립 검증 기록', 'decision.create': '가설 결정 기록', 'evidence.add': '원본 증거 연결'});
const MISSING_LABELS = Object.freeze({'execution receipt': '실행 결과 증거',
  'verified artifact metrics': '산출물의 검증된 지표',
  'confirmed terminal execution receipt': '실행 종료 여부가 확인된 결과 증거',
  'independent verification': '독립 검증'});
const CONDITION_LABELS = Object.freeze({comparison: '비교 기준', data_split: '데이터 분할', seed: 'Seed',
  source_version: '소스 버전', conditions: '실행 조건', validator: '등록 검증기'});
const OPS = Object.freeze({'>': (a, b) => a > b, '>=': (a, b) => a >= b,
  '<': (a, b) => a < b, '<=': (a, b) => a <= b, '==': (a, b) => a === b, '!=': (a, b) => a !== b});
const isObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
const finite = (value) => typeof value === 'number' && Number.isFinite(value);
const list = (value) => Array.isArray(value) ? value : [];
const unwrap = (value) => isObject(value) && value.ok === true && isObject(value.data) ? value.data : value;
const stable = (value) => JSON.stringify(Array.isArray(value) ? value.map((item) => JSON.parse(stable(item)))
  : isObject(value) ? Object.fromEntries(Object.keys(value).sort().map((key) => [key, JSON.parse(stable(value[key]))]))
    : value === undefined || (typeof value === 'number' && !finite(value)) ? null : value);

export function labelState(key, dimension = '') {
  if (key === 'failed' && dimension === 'execution') return '실행 실패';
  if (key === 'failed' && dimension === 'verification') return '검증 실패';
  return LABELS[key] || (typeof key === 'string' && key ? key : '미확인');
}

export function clipText(value, max = 180) {
  if (value === null || value === undefined) return '';
  const text = String(value).replace(/\s+/gu, ' ').trim();
  const length = Number.isInteger(max) && max > 0 ? max : 180;
  const characters = Array.from(text);
  return characters.length > length ? characters.slice(0, Math.max(0, length - 1)).join('') + '…' : text;
}

function asText(value) {
  if (value === undefined || value === null || value === '') return '미확인';
  if (Array.isArray(value)) return value.map(asText).join(' · ');
  if (isObject(value)) return Object.entries(value).map(([key, item]) => `${key}: ${asText(item)}`).join(' · ');
  return String(value);
}

function reference(workspace, registration, field, extra = {}) {
  return {workspace: workspace || '', ...(registration ? {registration} : {}), field, ...extra};
}

function conditions(spec, workspace = '', registration = '') {
  return ['comparison', 'data_split', 'seed', 'source_version', 'conditions', 'validator'].map((key) => ({
    label: CONDITION_LABELS[key], value: clipText(asText(key === 'source_version' ? spec.source_version?.label
      : key === 'conditions' ? spec.conditions || {} : spec[key]), 320),
    ref: reference(workspace, registration, `registration.spec.${key}`)}));
}

function unitFor(spec, name) {
  const candidates = [spec.metric_units?.[name], spec.units?.[name], spec.metric_metadata?.[name]?.unit];
  return candidates.find((unit) => typeof unit === 'string' && unit.trim())?.trim() || '단위 미등록';
}

function statesFor(record, summary = {}) {
  return {execution: record?.run?.state || summary.execution || (record?.registration ? 'registered' : 'unrecorded'),
    verification: record?.verification?.state || summary.verification || 'pending',
    decision: record?.decision?.state || summary.decision || 'pending'};
}

function supportFor(record) {
  const spec = record?.registration?.spec || {}, run = record?.run, verification = record?.verification;
  const evidence = list(record?.evidence), details = verification?.details || {};
  const invalid = evidence.filter((item) => ['tampered', 'missing'].includes(item.integrity));
  const linked = evidence.filter((item) => item.run_id === run?.id);
  const artifacts = list(spec.artifacts);
  const linkedCorrectly = !!(record?.registration?.id && run?.id && run.registration_id === record.registration.id &&
    verification?.run_id === run.id && /^[a-f\d]{64}$/i.test(spec.validator_sha256 || '') && details.validator_sha256 === spec.validator_sha256);
  const sourceFiles = Object.entries(spec.source_version?.files || {});
  const sourceComplete = sourceFiles.length > 0 && sourceFiles.every(([path, digest]) =>
    linked.some((item) => item.name === `source:${path}` && item.sha256 === digest && item.integrity === 'valid'));
  const evidenceComplete = linked.length > 0 && invalid.length === 0 &&
    linked.every((item) => item.integrity === 'valid' && item.registration_id === record.registration.id) &&
    sourceComplete && artifacts.length > 0 && artifacts.every((artifact) => linked.some((item) =>
      item.name === artifact.name && item.kind === 'measured' && item.path && item.integrity === 'valid'));
  const integrity = details.integrity !== false && !details.error && !list(details.missing_artifacts).length &&
    !list(details.missing_metrics).length;
  const measured = run?.state === 'succeeded' && ['passed', 'failed'].includes(verification?.state) &&
    linkedCorrectly && evidenceComplete && integrity;
  const criteria = list(spec.criteria);
  const outcomes = criteria.map((criterion) => {
    const actual = verification?.metrics?.[criterion.metric];
    if (!measured || !finite(actual) || !finite(criterion.threshold) || !OPS[criterion.op]) return null;
    const stored = list(details.criteria_results).find((result) => result.metric === criterion.metric &&
      result.op === criterion.op && result.threshold === criterion.threshold && result.actual === actual &&
      typeof result.passed === 'boolean');
    const evaluated = OPS[criterion.op](actual, criterion.threshold);
    return stored && stored.passed === evaluated ? evaluated : null;
  });
  const consistent = criteria.length > 0 && outcomes.every((value) => typeof value === 'boolean') &&
    (verification?.state === 'passed' ? outcomes.every((value) => value === true) : outcomes.some((value) => value === false));
  return {measured: measured && consistent, supported: measured && consistent && verification?.state === 'passed' && criteria.length > 0 &&
    outcomes.every((value) => value === true), outcomes, invalid,
    valid: evidence.filter((item) => item.integrity === 'valid'), evidence, linkedCorrectly, evidenceComplete};
}

function numericDomain(values) {
  const finiteValues = values.filter(finite);
  if (!finiteValues.length) return [0, 1];
  let min = Math.min(...finiteValues), max = Math.max(...finiteValues);
  // Padding makes both the measured point and every threshold visible; zero is not assumed.
  if (min === max) {
    const padding = Math.max(Math.abs(min) * 0.1, 1);
    if (finite(min - padding)) min -= padding;
    if (finite(max + padding)) max += padding;
  } else {
    const span = max - min;
    const padding = finite(span) ? span * 0.12 : 0;
    if (finite(min - padding)) min -= padding;
    if (finite(max + padding)) max += padding;
  }
  return [min, max];
}

function metricModels(record, workspace = '') {
  workspace = record?.workspace || workspace;
  const spec = record?.registration?.spec || {}, registration = record?.registration?.id || '';
  const support = supportFor(record), criteria = list(spec.criteria);
  return list(spec.metrics).filter((name) => typeof name === 'string').map((name) => {
    const actual = record?.verification?.metrics?.[name], value = finite(actual) ? actual : null;
    const tests = criteria.map((criterion, index) => ({criterion, index})).filter((item) => item.criterion.metric === name)
      .map(({criterion, index}) => ({op: criterion.op, threshold: finite(criterion.threshold) ? criterion.threshold : null,
        actual: value, passed: support.measured ? support.outcomes[index] : null,
        ref: reference(workspace, registration, `registration.spec.criteria[${index}]`,
          {run: record?.verification?.run_id || '', metric: name})}));
    return {name, value, unit: unitFor(spec, name), criteria: tests,
      supported: support.measured && value !== null && tests.length > 0 && tests.every((test) => test.passed !== null),
      ref: reference(workspace, registration, `verification.metrics.${name}`, {run: record?.verification?.run_id || ''}),
      domain: numericDomain([value, ...tests.map((test) => test.threshold)])};
  });
}

function trustModel(record, workspace, states) {
  const support = supportFor(record), registration = record?.registration?.id || '';
  let text = '독립 검증이 없어 현재 성공 주장을 확인할 수 없습니다.', tone = 'quiet';
  if (support.invalid.length) {
    text = `현재 원본 ${support.invalid.length}개의 누락·변조가 감지됐습니다. 과거 검증·채택 기록과 구분해야 합니다.`;
    tone = 'warn';
  } else if (support.supported) {
    text = '등록 기준을 독립 검증이 통과했고 연결된 실행 원본의 해시가 현재 일치합니다. 적용 범위를 함께 확인하세요.';
    tone = 'good';
  } else if (states.verification === 'failed' && support.measured) {
    text = '독립 검증에서 등록 기준 미달이 확인됐습니다. 실행 원본의 해시는 현재 일치합니다.';
    tone = 'bad';
  } else if (states.verification === 'failed') {
    text = '독립 검증 실패 기록은 있지만 현재 원본·등록 기준·검증 연결은 충분히 확인되지 않았습니다.';
    tone = 'warn';
  } else if (states.verification === 'passed') {
    text = '과거 검증 통과 기록은 있지만 현재 원본·등록 기준·검증 연결이 충분하지 않아 성공 주장은 미확인입니다.';
    tone = 'warn';
  } else if (states.verification === 'inconclusive') {
    text = '독립 검증은 미결입니다. 보존 파일의 해시 일치만으로 가설이 검증되지는 않습니다.';
  } else if (states.execution === 'unknown') {
    text = '실행 여부가 미확정입니다. 종료 증거를 확인하기 전에는 결과를 확정할 수 없습니다.';
  } else if (states.execution === 'failed') {
    text = '실행 실패 기록입니다. 실행 성공·독립 검증·가설 채택을 별도로 확인해야 합니다.';
    tone = 'bad';
  }
  const refs = [reference(workspace, registration, 'verification', {run: record?.verification?.run_id || ''}),
    ...support.evidence.map((item) => reference(workspace, registration, 'evidence.integrity', {evidence: item.id}))];
  return {supported: support.supported, invalidCount: support.invalid.length, validCount: support.valid.length,
    total: support.evidence.length, text, tone, refs};
}

function stageModel(states, trust, record, summary) {
  if (trust.invalidCount) return {text: '현재 원본 확인 필요', tone: 'warn'};
  if (states.execution === 'unknown') return {text: '실행 여부 확인 필요', tone: 'warn'};
  if (states.execution === 'running') return {text: '실행 진행 중', tone: 'warn'};
  if (states.execution === 'failed') return {text: '실행 실패 기록', tone: 'bad'};
  if (states.verification === 'failed') return {text: supportFor(record).measured ? '검증 기준 미달' : '독립 검증 실패 기록', tone: 'bad'};
  if (states.verification === 'inconclusive') return {text: '검증 미결', tone: 'quiet'};
  if (states.decision === 'adopted') return {text: trust.supported ? '채택 기록 · 적용 범위 확인' : '채택 기록 · 현재 근거 확인 필요', tone: trust.supported ? 'good' : 'warn'};
  if (states.decision === 'rejected') return {text: '기각 결정 기록', tone: 'bad'};
  if (states.decision === 'inconclusive') return {text: '미결 결정 기록', tone: 'quiet'};
  if (states.verification === 'passed') return {text: trust.supported ? '독립 검증 통과 · 결정 대기' : '과거 검증 통과 · 현재 근거 확인 필요', tone: trust.supported ? 'good' : 'warn'};
  if (list(summary?.missing_evidence).includes('independent verification')) return {text: '독립 검증 대기', tone: 'quiet'};
  if (record?.registration || summary?.id) return {text: '조건 고정 · 결과 증거 대기', tone: 'quiet'};
  return {text: '등록된 실험 없음', tone: 'quiet'};
}

function resourceModels(record, workspace) {
  const resources = record?.run?.resources || {}, registration = record?.registration?.id || '';
  const wallKnown = finite(resources.wall_seconds) && resources.wall_seconds >= 0;
  const tokens = finite(resources.external_tokens) && resources.external_tokens >= 0 ? resources.external_tokens
    : resources.tokens?.status === 'known' && finite(resources.tokens.value) && resources.tokens.value >= 0 ? resources.tokens.value : null;
  const model = resources.external_model_usage;
  const modelKnown = typeof model === 'string' && model.trim() !== '' && model !== 'unknown';
  return [{label: '실행 경과 시간', value: wallKnown ? `${resources.wall_seconds}초` : '미확인', known: wallKnown,
    ref: reference(workspace, registration, 'run.resources.wall_seconds')},
  {label: '외부 모델 사용', value: modelKnown ? clipText(model, 180) : '미확인', known: modelKnown,
    ref: reference(workspace, registration, 'run.resources.external_model_usage')},
  {label: '외부 토큰 사용', value: tokens === null ? '미확인' : `${tokens} 토큰`, known: tokens !== null,
    ref: reference(workspace, registration, finite(resources.external_tokens) ? 'run.resources.external_tokens' : 'run.resources.tokens')}];
}

function distribution(items, dimension, keys) {
  const counts = new Map(keys.map((key) => [key, 0]));
  for (const item of items) {
    const key = typeof item[dimension] === 'string' ? item[dimension] : 'unrecorded';
    counts.set(key, (counts.get(key) || 0) + 1);
  }
  return [...counts].map(([key, count]) => ({key, label: labelState(key, dimension), count}));
}

function lessonModels(memory, workspace) {
  return list(memory?.items).map((item, index) => {
    let claimText = '독립 검증 대기 · 기록 존재와 주장 검증은 별개', tone = 'quiet';
    if (item.evidence_integrity === 'invalid') {
      claimText = '현재 원본 누락·변조 · 과거 판정과 구분'; tone = 'warn';
    } else if (item.verification === 'failed') {
      claimText = item.evidence_integrity === 'valid' ? '독립 검증 실패 기록 · 현재 원본 해시 일치' : '독립 검증 실패 기록 · 현재 원본 미확인';
      tone = 'bad';
    } else if (item.claim_verified === true && item.verification === 'passed' && item.evidence_integrity === 'valid') {
      claimText = '독립 검증 통과 · 현재 원본 해시 일치'; tone = 'good';
    } else if (item.verification === 'passed') {
      claimText = '과거 검증 통과 · 현재 성공 주장 미확인'; tone = 'warn';
    } else if (item.verification === 'inconclusive') {
      claimText = '독립 검증 미결 · 추가 근거 필요';
    } else if (item.execution === 'unknown') {
      claimText = '실행 미확정 · 종료 증거 확인 필요';
    } else if (item.execution === 'failed') {
      claimText = '실행 실패 기록 · 독립 검증과 별도'; tone = 'bad';
    }
    return {title: clipText(item.summary || item.hypothesis || '등록된 시도', 110),
      summary: clipText(item.hypothesis || item.summary, 220), reason: clipText(item.reason || '결정 이유 미기록', 260),
      outcome: item.outcome || 'inconclusive', claimText, tone,
      conditions: conditions(item.conditions || {}).filter((entry) => ['비교 기준', '데이터 분할', 'Seed', '소스 버전'].includes(entry.label))
        .map(({label, value}) => ({label, value})),
      ref: reference(workspace, item.id, `memory.items[${index}]`, {goal: item.goal_id || ''})};
  });
}

/** Deterministic, bounded text and exact numbers; the caller chooses how many cards to reveal. */
export function buildViewModel({snapshot, record, goal, summary, memory, records, limit, offset, workspace = ''} = {}) {
  snapshot = unwrap(snapshot) || {}; record = unwrap(record) || null; memory = unwrap(memory) || {};
  workspace = record?.workspace || workspace;
  const status = snapshot.status || snapshot, spec = record?.registration?.spec || {};
  const registration = record?.registration?.id || '', hypotheses = list(status.hypotheses);
  const selectedSummary = summary?.id === registration || (!registration && summary?.id) ? summary
    : list(status.registrations).find((item) => item.id === registration) || {};
  const suppliedGoal = unwrap(goal);
  const selectedGoal = (suppliedGoal && (!registration || suppliedGoal.id === record.registration.goal_id) ? suppliedGoal : null) ||
    list(status.goals).find((item) => item.id === record?.registration?.goal_id) ||
    (!registration ? list(status.goals)[0] : null) || {};
  const hypothesis = record?.hypothesis || hypotheses.find((item) => item.id === record?.registration?.hypothesis_id) ||
    (!registration ? hypotheses.find((item) => item.goal_id === selectedGoal.id) : null) || {};
  const states = statesFor(record, selectedSummary), trust = trustModel(record, workspace, states);
  const items = list(status.registrations), count = items.length;
  const total = Number.isInteger(status.total) && status.total >= 0 ? status.total : count;
  const pageOffset = Number.isInteger(status.offset) && status.offset >= 0 ? status.offset : Number.isInteger(offset) && offset >= 0 ? offset : 0;
  const metrics = metricModels(record, workspace), conditionModels = conditions(spec, workspace, registration);
  const blockers = list(selectedSummary.missing_evidence).map((text, index) => ({text: MISSING_LABELS[text] || clipText(text, 180),
    ref: reference(workspace, registration, `status.registrations.missing_evidence[${index}]`, {value: text})}));
  if (trust.invalidCount > 0) {
    const invalid = list(record?.evidence).filter((item) => ['tampered', 'missing'].includes(item.integrity));
    blockers.unshift({text: `현재 증거 원본 ${trust.invalidCount}개의 누락·변조가 감지되어 복원 또는 원본 대조가 필요합니다.`,
      ref: reference(workspace, registration, 'evidence.integrity',
        {evidence: invalid[0]?.id, evidence_ids: invalid.map((item) => item.id)})});
  }
  if (record && finite(status.revision) && finite(record.revision) && status.revision !== record.revision) {
    blockers.push({text: '조회 시점이 달라 화면 갱신이 필요합니다.', ref: reference(workspace, registration, 'revision', {revision: record.revision})});
  }
  if (finite(status.revision) && finite(memory.revision) && status.revision !== memory.revision) {
    blockers.push({text: '기억의 조회 시점이 달라 화면 갱신이 필요합니다.', ref: reference(workspace, registration, 'memory.revision', {revision: memory.revision})});
  }
  const timelineItems = list(snapshot.events).map((event) => ({title: EVENT_LABELS[event.action] || clipText(event.action || '연구 사건', 80),
    created: finite(event.created) ? event.created : null, revision: finite(event.revision) ? event.revision : null,
    ref: reference(workspace, '', 'snapshot.events', {event: event.id, target: event.target, revision: event.revision})}))
    .sort((a, b) => (a.created ?? Infinity) - (b.created ?? Infinity) || (a.revision ?? Infinity) - (b.revision ?? Infinity));
  const eventTotal = Number.isInteger(snapshot.event_total) && snapshot.event_total >= 0 ? snapshot.event_total : timelineItems.length;
  const questionRefs = [reference(workspace, registration, 'goal.title', {goal: selectedGoal.id || ''}),
    reference(workspace, registration, 'hypothesis.statement', {hypothesis: hypothesis.id || ''}),
    reference(workspace, registration, 'registration.spec.change'),
    selectedGoal.description ? reference(workspace, registration, 'goal.description', {goal: selectedGoal.id || ''})
      : reference(workspace, registration, 'registration.spec.data_split')];
  const model = {question: {title: clipText(selectedGoal.title || '연구 목표 미기록', 160),
    hypothesis: clipText(hypothesis.statement || '가설 미기록', 240), change: clipText(spec.change || '실험 변경점 미등록', 200),
    scope: clipText(selectedGoal.description || asText(spec.data_split?.evaluation || spec.data_split), 180), refs: questionRefs},
  states, stage: stageModel(states, trust, record, selectedSummary), trust, blockers, metrics, conditions: conditionModels,
  resources: resourceModels(record, workspace), scope: {count, total, offset: pageOffset,
    label: `이 조회 ${count}건 / 전체 등록 ${total}건${count ? ` · ${pageOffset + 1}–${pageOffset + count}번째` : ''}`},
  distribution: {execution: distribution(items, 'execution', ['registered', 'running', 'succeeded', 'failed', 'unknown']),
    verification: distribution(items, 'verification', ['pending', 'passed', 'failed', 'inconclusive']),
    decision: distribution(items, 'decision', ['pending', 'adopted', 'rejected', 'inconclusive'])},
  timeline: {items: timelineItems, total: eventTotal,
    label: snapshot.event_scope === 'selected_registration'
      ? `선택 실험 연결 사건 ${timelineItems.length}건 / 전체 연결 ${eventTotal}건`
      : `최근 조회 사건 ${timelineItems.length}건 / 전체 ${eventTotal}건`},
  lessons: lessonModels(memory, workspace)};
  model.refs = [...questionRefs, ...trust.refs, ...blockers.map((item) => item.ref), ...metrics.flatMap((item) => [item.ref, ...item.criteria.map((criterion) => criterion.ref)]),
    ...conditionModels.map((item) => item.ref), ...model.resources.map((item) => item.ref), ...timelineItems.map((item) => item.ref), ...model.lessons.map((item) => item.ref),
    reference(workspace, '', 'status.registrations', {offset: pageOffset, limit: status.limit || limit || 20}),
    reference(workspace, '', 'memory', {offset: memory.offset || 0, limit: memory.limit || 20})];
  if (snapshot.registration) model.refs.push(reference(workspace, snapshot.registration, 'snapshot.registration',
    {event_scope: snapshot.event_scope || 'workspace'}));
  return model;
}

function comparisonConditions(record) {
  const spec = record?.registration?.spec || {};
  return {goal: record?.registration?.goal_id, comparison: spec.comparison, data_split: spec.data_split, seed: spec.seed,
    metrics: list(spec.metrics).map((name) => ({name, unit: unitFor(spec, name)})).sort((a, b) => String(a.name).localeCompare(String(b.name))),
    criteria: list(spec.criteria).map((criterion) => ({metric: criterion.metric, op: criterion.op, threshold: criterion.threshold}))
      .sort((a, b) => stable(a).localeCompare(stable(b))),
    conditions: spec.conditions || {}, validator_sha256: spec.validator_sha256};
}

function incompleteConditions(record) {
  const spec = record?.registration?.spec || {}, missing = [];
  if (!record?.registration?.goal_id) missing.push('연구 목표 연결');
  if (typeof spec.comparison !== 'string' || !spec.comparison.trim()) missing.push('비교 기준');
  if (!((typeof spec.data_split === 'string' && spec.data_split.trim()) || (isObject(spec.data_split) && Object.keys(spec.data_split).length))) missing.push('데이터 분할');
  if (!Number.isInteger(spec.seed)) missing.push('seed');
  if (!list(spec.metrics).length || list(spec.metrics).some((item) => typeof item !== 'string' || !item)) missing.push('등록 지표');
  if (!list(spec.criteria).length || list(spec.criteria).some((criterion) => !finite(criterion.threshold) || !OPS[criterion.op] || !list(spec.metrics).includes(criterion.metric))) missing.push('등록 기준');
  if (spec.conditions !== undefined && !isObject(spec.conditions)) missing.push('실행 조건');
  if (typeof spec.validator_sha256 !== 'string' || !/^[a-f\d]{64}$/i.test(spec.validator_sha256)) missing.push('고정 검증기');
  if (!spec.source_version?.label || !isObject(spec.source_version?.files) || !Object.keys(spec.source_version.files).length) missing.push('소스 버전');
  return missing;
}

/** Cohorts are registration-compatible candidates, never a performance ranking. */
export function compareRecords(records = []) {
  const loaded = list(records).map(unwrap).filter((record) => record?.registration), seen = new Set();
  // Restoring an export retains registration IDs; copies are not additional experimental attempts.
  const originals = loaded.filter((record) => {
    if (!record.registration.id || seen.has(record.registration.id)) return false;
    seen.add(record.registration.id); return true;
  });
  const duplicates = loaded.length - originals.length, groups = new Map();
  const allConditions = originals.map(comparisonConditions), differenceLabels = {goal: '연구 목표', comparison: '비교 기준', data_split: '데이터 분할',
    seed: 'seed', metrics: '지표·단위', criteria: '등록 기준', conditions: '실행 조건', validator_sha256: '고정 검증기'};
  const differing = Object.keys(differenceLabels).filter((key) => new Set(allConditions.map((item) => stable(item[key]))).size > 1);
  originals.forEach((record, index) => {
    const missing = incompleteConditions(record), signature = missing.length ? `incomplete:${index}` : stable(allConditions[index]);
    if (!groups.has(signature)) groups.set(signature, {records: [], missing, condition: allConditions[index]});
    groups.get(signature).records.push(record);
  });
  return [...groups.values()].map((group, index) => {
    const comparable = group.records.length >= 2 && !group.missing.length;
    const changes = [...new Set(group.records.map((record) => clipText(record.registration.spec.change, 140)))];
    const versions = [...new Set(group.records.map((record) => clipText(record.registration.spec.source_version?.label, 100)))];
    const sourceFiles = new Set(group.records.map((record) => stable(record.registration.spec.source_version?.files)));
    const differences = differing.length ? [`다른 묶음과 조건 차이: ${differing.map((key) => differenceLabels[key]).join(' · ')}`] : [];
    if (duplicates) differences.push(`같은 등록의 반복 조회 ${duplicates}건은 별도 실험으로 세지 않습니다.`);
    if (versions.length > 1) differences.push(`소스 버전 차이: ${versions.join(' · ')}`);
    if (sourceFiles.size > 1) differences.push('사전 고정된 소스 파일 내용이 서로 다릅니다. 버전 이름만으로 동일성을 판단하지 않습니다.');
    if (changes.length > 1) differences.push(`시험한 변경점: ${changes.join(' · ')}`);
    const reason = group.missing.length ? `비교 조건 미확인: ${group.missing.join(' · ')}`
      : comparable ? `등록에 적힌 비교 조건이 같은 ${group.records.length}건입니다. 미등록 조건의 동일성은 확인되지 않았습니다.`
        : '같은 등록 조건의 두 번째 시도가 없어 수치 비교를 구성할 수 없습니다.';
    return {key: `cohort-${index + 1}`, comparable, reason, conditions: conditions(group.records[0].registration.spec,
      group.records[0].workspace || '', group.records[0].registration.id), differences,
      items: group.records.map((record) => ({title: clipText(record.registration.spec.change || record.hypothesis?.statement || '등록된 시도', 150),
        registration: record.registration.id, source: clipText(record.registration.spec.source_version?.label || '소스 버전 미확인', 120),
        states: statesFor(record), metrics: metricModels(record),
        refs: [reference(record.workspace || '', record.registration.id, 'registration.spec'),
          reference(record.workspace || '', record.registration.id, 'verification', {run: record.verification?.run_id || ''})]}))};
  });
}
