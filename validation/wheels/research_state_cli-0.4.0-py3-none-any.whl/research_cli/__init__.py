"""Research state management, without a model or agent runtime."""
__version__ = "0.4.0"
