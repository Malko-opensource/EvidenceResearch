"""Frozen independent constants for the development task, not scientific performance."""
import json
import math
from pathlib import Path
import sys

context = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
artifact = next(item for item in context['evidence'] if item['name'] == 'result')
data = json.loads(Path(artifact['path']).read_text(encoding='utf-8'))
checks = [math.isclose(data['mean'], 5.0, abs_tol=1e-12), math.isclose(data['variance'], 9.0, abs_tol=1e-12)]
print(json.dumps({'status': 'passed' if all(checks) else 'failed', 'metrics': {'pass_rate': sum(checks) / len(checks)}, 'details': {'independent_expected_mean': 5, 'independent_expected_variance': 9, 'checks': checks}}))
