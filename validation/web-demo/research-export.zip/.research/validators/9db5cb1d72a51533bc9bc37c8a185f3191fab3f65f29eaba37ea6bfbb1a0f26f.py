"""Owner-frozen independent fixture checks actual preserved artifact values."""
import json
from pathlib import Path
import sys

bundle = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
result = json.loads(Path(bundle["artifacts"]["result"]).read_text(encoding="utf-8"))
checks = [result.get("mean") == 5, result.get("variance") == 8]
print(json.dumps({"metrics": {"pass_rate": sum(checks) / len(checks)},
                  "details": {"expected_mean": 5, "expected_variance": 8,
                              "observed": result, "development_fixture": True}}))
